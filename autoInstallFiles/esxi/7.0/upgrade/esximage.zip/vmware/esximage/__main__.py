########################################################################
# Copyright (C) 2017-2019 VMWare, Inc.                                 #
# All Rights Reserved                                                  #
########################################################################

"""
Command-line wrapper for esximage library.
"""
import argparse
import datetime
import json
import os
import shutil
import subprocess
import sys
import tempfile
from copy import copy

from esximage import (Addon, BaseImage, Bulletin, ConfigSchema, Depot,
                      ImageProfile, ReleaseCollection, Solution, Version, Vib)

def bulletin(args):
   """Write an ESXi bulletin.
   """
   disabledVibs = set()
   if args.disableList:
      for line in args.disableList.readlines():
         disabledVibs.add(line.strip())

   vibIds = set()
   configSchemaVibs = set()
   for vibPath in args.vibs:
      v = Vib.ArFileVib.FromFile(vibPath)
      if v.id not in disabledVibs:
         vibIds.add(v.id)
      if v.GetConfigSchemaTag() is not None:
         configSchemaVibs.add(v.id)

   spec = copy(args.spec)
   spec['configSchemaVibs'] = configSchemaVibs
   bulletin = Bulletin.Bulletin(vibids=vibIds, **args.spec)
   args.output.write(str(bulletin))


def depot(args):
   """Create the VIB metadata (metadata.zip, index.xml, and vendor-index.xml).
   """
   metadata = Depot.MetadataNode(url=args.url, productId='embeddedEsx',
                                 version=args.version,
                                 channels=['esx-' + args.version])
   relativePaths = dict()
   if args.vib:
      csc = ConfigSchema.ConfigSchemaCollection()
      disabledVibs = set()
      if args.disableList:
         for line in args.disableList.readlines():
            disabledVibs.add(line.strip())

      for vib in args.vib:
         with open(vib, 'rb') as fobj:
            # If passing the path string, the resulting VIB object won't be
            # able to refer to the payload inside the VIB to extract config
            # schema.
            v = Vib.ArFileVib.FromFile(fobj)

            if v.id in disabledVibs:
               v.Close()
               continue

            dest = os.path.join(args.depotDir, v.GetRelativePath())
            destDir = os.path.dirname(dest)
            shutil.rmtree(destDir, ignore_errors=True)
            os.makedirs(destDir)
            # Optimize VIB copying with hardlink
            # This may fail with "invalid cross-device link" when linking a
            # VIB from the shared compcache to a local build tree.
            if args.vibHardlink:
               try:
                  os.link(vib, dest)
               except OSError:
                  shutil.copyfile(vib, dest)
            else:
               shutil.copyfile(vib, dest)

            # Add config schema.
            cs = Vib.getConfigSchema(v, args.xz, args.tmpDir)
            if cs is not None:
               csc.AddConfigSchema(cs)
            v.Close()

   metadata.vibs.FromDirectory(args.depotDir, ignoreinvalidfiles=True,
                               validate=False, metadataonly=True)
   metadata.configSchemas = csc

   if args.profile:
      for profile in args.profile:
         metadata.profiles.AddProfileFromXml(profile.read(), validate=False)

   if args.bulletin:
      for bulletin in args.bulletin:
         b = Bulletin.Bulletin.FromXml(bulletin.read())
         metadata.bulletins.AddBulletin(b)

   if args.baseimage:
      for baseImg in args.baseimage:
         metadata.baseimages.AddFromJSON(baseImg.read())

   if args.addon:
      for addon in args.addon:
         metadata.addons.AddFromJSON(addon.read())

   metadata.AddPlatform('ESXi', args.version)

   if args.outZip:
      metadata.WriteMetadataZip(args.outZip)

   vendorIndex = Depot.VendorIndex(name='VMware', code='vmw',
                                   indexfile=os.path.basename(args.outVendorIndex.name),
                                   children=[metadata],
                                   contentName="VMware ESXi",
                                   contentType="http://www.vmware.com/depotmanagement/esx")
   if args.outVendorIndex:
      args.outVendorIndex.write(vendorIndex.ToString().decode())

   depotIndex = Depot.DepotIndex(children=[vendorIndex])
   if args.outIndex:
      args.outIndex.write(depotIndex.ToString().decode())


def imageProfile(args):
   """Write an ESXi image profile.
   """
   bulletins = Bulletin.BulletinCollection()
   if args.bulletin:
      for bulletin in args.bulletin:
         b = Bulletin.Bulletin.FromXml(bulletin.read())
         bulletins.AddBulletin(b)

   resCompIDs = set()
   finalComps = Bulletin.ComponentCollection(bulletins)
   baseImg, addOn, baseImgID, addonID = None, None, None, None
   if args.baseimage:
      baseImg = BaseImage.BaseImage.FromJSON(args.baseimage.read())
      baseImgID = baseImg.releaseID
      resCompIDs.update(set(baseImg.CollectReservedComponents(finalComps)))

   if args.addon:
      addOn = Addon.Addon.FromJSON(args.addon.read())
      addonID = addOn.releaseID
      resCompIDs.update(set(addOn.CollectReservedComponents(finalComps)))

   profile = ImageProfile.ImageProfile(**args.spec, baseimageID=baseImgID,
                                       baseimage=baseImg, addon=addOn,
                                       addonID=addonID,
                                       bulletinIDs=set(bulletins.keys()),
                                       bulletins=bulletins,
                                       reservedComponentIDs=resCompIDs)

   disabledVibs = set()
   if args.disableList:
      for line in args.disableList.readlines():
         disabledVibs.add(line.strip())

   for vibPath in args.vibs:
      v = Vib.ArFileVib.FromFile(vibPath)
      if v.id not in disabledVibs:
         profile.AddVib(v)

   if args.validate:
      problems = profile.Validate()
      if problems:
         raise Exception('Failed to validate ImageProfile %s: %s' %
                         (profile.name, problems))

   args.output.write(str(profile))


def baseImage(args):
   """Write an ESXi base image.
   """
   image = BaseImage.BaseImage()
   image.FromJSONDict(args.imageSpec)

   if args.components:
      for component in args.components:
         try:
            b = Bulletin.Bulletin.FromXml(component.read())
            comp = Bulletin.Component.FromBulletin(b)
            image.AddComponent(comp)
         except Exception as err:
            raise Exception('Failed to add component to BaseImage %s.\n'
                            'Reason: %s\n' % (image.releaseID, str(err)))

   if args.validate:
      problems = image.Validate()
      if problems:
         raise Exception('Failed to validate BaseImage %s: %s' %
                         (image.releaseID, problems))

   args.output.write(image.ToJSON())


def addon(args):
   """Generate an addon for the software image.
   """
   addon = Addon.Addon()
   addon.FromJSONDict(args.addonSpec)

   if args.components:
      for component in args.components:
         try:
            b = Bulletin.Bulletin.FromXml(component.read())
            comp = Bulletin.Component.FromBulletin(b)
            addon.AddComponent(comp)
         except Exception as err:
            raise Exception('Failed to add component to an Addon %s.\n'
                            'Reason: %s\n' % (addon.releaseID, str(err)))

   if args.removedComponents:
      for component in args.removedComponents:
         try:
            b = Bulletin.Bulletin.FromXml(component.read())
            comp = Bulletin.Component.FromBulletin(b)
            addon.AddRemovedComponent(comp.compNameStr)
         except Exception as err:
            raise Exception('Failed to add component to an Addon %s.\n'
                            'Reason: %s\n' % (addon.releaseID, str(err)))

   if args.validate:
      problems = addon.Validate()
      if problems:
         raise Exception('Failed to validate an Addon %s: %s' %
                         (addon.releaseID, problems))

   args.output.write(addon.ToJSON())


def softwareSpec2IP(args):
   """Generate an addon for the software image."""
   # We can't use this import globally because it will pull in the python SSL
   # library. All invocations of python calls in the build will then have
   # to be changed.
   from esximage.ImageManager import DepotMgr, SoftwareSpecMgr

   with open(args.softwareSpec, 'r') as f:
      softwareSpecJson = json.load(f)

   depotSpec = dict(name='depot1', url=args.depot)

   depotMgr = DepotMgr.DepotMgr(depotSpecs=[depotSpec], connect=True)
   softwareSpecMgr = SoftwareSpecMgr.SoftwareSpecMgr(depotMgr, softwareSpecJson)
   imageProfile = softwareSpecMgr.validateAndReturnImageProfile(checkAcceptance=False)
   args.output.write(str(imageProfile))


def _signVib(vibObj, keyids, tmpDir):
   """Sign VIB descriptor using signc.
   """
   SIGNC = "/build/toolchain/noarch/vmware/signserver/signc"

   if not tmpDir:
      raise Exception("--tmpDir is required to sign a VIB")

   fd, descriptorFile = tempfile.mkstemp(dir=tmpDir)
   os.write(fd, vibObj.ToXmlString())
   os.close(fd)

   fd, signatureFile = tempfile.mkstemp(dir=tmpDir)
   os.close(fd)

   vibObj.ClearSignature()
   try:
      for keyid in keyids:
         cmd = [SIGNC,
                "--input=%s" % descriptorFile,
                "--signmethod=vibsign-1.0",
                "--keyid=%s" % keyid,
                "--output=%s" % signatureFile]
         subprocess.check_call(cmd)
         with open(signatureFile, "rb") as f:
            vibObj.AddSignatureText(f.read())
   finally:
      os.unlink(descriptorFile)
      os.unlink(signatureFile)


def vib(args):
   """Write an ESXi VIB.
   """
   # Convert text spec to constructor-ready format
   vibSpec = args.spec.copy()
   vibSpec['version'] = Version.VibVersion.fromstring(args.spec['version'])
   for key in ('depends', 'conflicts', 'replaces'):
      vibSpec[key] = [Vib.VibRelation.FromString(s) for s in args.spec[key]]
   vibSpec['provides'] = [Vib.VibProvide.FromString(s)
                          for s in args.spec['provides']]
   vibSpec['maintenancemode'] = Vib.MaintenanceMode(
                                 args.spec['maintenancemode'][0],
                                 args.spec['maintenancemode'][1])
   vibSpec['hwplatforms'] = []
   for p in args.spec['hwplatforms']:
      vibSpec['hwplatforms'].append(Vib.HwPlatform(p[0], p[1]))
   vibSpec['releasedate'] = datetime.datetime.strptime(
                              args.spec['releasedate'], '%Y-%m-%dT%H:%M:%S.%f')

   # Construct and add payloads
   vibObj = Vib.ArFileVib(**vibSpec)

   if args.payload:
      for payload in args.payload:
         payloadPath, ptype, porder, pname, vfatName, useXZ, txtmle \
                                                         = payload.split(',')
         # Covert True/False values
         useXZ = (useXZ.lower() == 'true')
         txtmle = (txtmle.lower() == 'true')
         pObj = Vib.Payload(pname, ptype, int(porder), vfatName)
         if useXZ and not (args.xz and args.tmpDir):
            raise Exception('--xz and --tmpDir are required for payload %s '
                            'that uses XZ' % pname)
         elif txtmle and not args.objcopy:
            raise Exception('--objcopy is required for payload %s that requires'
                            ' txt-mle checksum to be added' % pname)
         xzip = args.xz if useXZ else None
         tmpDir = args.tmpDir if useXZ else None
         objcopy = args.objcopy if txtmle else None
         vibObj.AddPayload(pObj, payloadPath, xzip=xzip, tmpDir=tmpDir,
                           objcopy=objcopy)

   # Sign VIB
   if args.keyid:
      _signVib(vibObj, args.keyid, args.tmpDir)

   # Write out VIB
   vibObj.WriteVibFile(args.output)


def main(args=None):
   parser = argparse.ArgumentParser(prog='python -m esximage')

   subparsers = parser.add_subparsers(dest='cmd', title='subcommands')

   bulletinParser = subparsers.add_parser('bulletin', help='bulletin help')
   bulletinParser.add_argument('vibs', help="VIB files to include",
                               nargs="+")
   # python2to3 note: FileType('w', encoding='UTF-8')
   bulletinParser.add_argument('--disableList', help="File of VIBs to exclude",
                               type=argparse.FileType('r'))
   bulletinParser.add_argument('--output', help="Output filename [stdout]",
                               type=argparse.FileType('w'),
                               default='-')
   bulletinParser.add_argument('--spec', help="Object spec dictionary (JSON)",
                               type=json.loads, required=True)
   bulletinParser.set_defaults(func=bulletin)

   depotParser = subparsers.add_parser('depot', help='depot help')
   depotParser.add_argument('--version', help="Depot platform version",
                            required=True)
   depotParser.add_argument('--url', help="URL of metadata.zip",
                            required=True)
   depotParser.add_argument('--depotDir', help="Depot directory to load",
                            required=True)
   depotParser.add_argument('--vibHardlink', help="Hardlink VIBs into Depot instead of copying",
                            action='store_true')
   # python2to3 note: FileType('r', encoding='UTF-8')
   depotParser.add_argument('--disableList', help="File of VIBs to exclude",
                            type=argparse.FileType('r'))
   depotParser.add_argument('--bulletin', help="Bulletin(s)",
                            type=argparse.FileType('r'),
                            nargs="*")
   depotParser.add_argument('--profile', help="ImageProfile(s)",
                            type=argparse.FileType('r'),
                            nargs="*")
   depotParser.add_argument('--baseimage', help="Base Image(s)",
                            type=argparse.FileType('r'),
                            nargs="*")
   depotParser.add_argument('--addon', help="AddOn(s)",
                            type=argparse.FileType('r'),
                            nargs="*")
   depotParser.add_argument('--vib', help="VIB files to include",
                            nargs="*")
   depotParser.add_argument('--outZip', help="Output metadata.zip path")
   depotParser.add_argument('--outIndex', help="Output index.xml path",
                            type=argparse.FileType('w'))
   depotParser.add_argument('--outVendorIndex', help="Output vendor-index.xml path",
                            type=argparse.FileType('w'))
   depotParser.add_argument('--xz', help="xz binary path for decompress")
   depotParser.add_argument('--tmpDir', help="temp dir for xz decompress")
   depotParser.set_defaults(func=depot)

   imgParser = subparsers.add_parser('imageProfile', help='image profile help')
   imgParser.add_argument('vibs', help="VIB files to include",
                          nargs="+")
   # python2to3 note: FileType('w', encoding='UTF-8')
   imgParser.add_argument('--disableList', help="File of VIBs to exclude",
                          type=argparse.FileType('r'))
   imgParser.add_argument('--output', help="Output filename [stdout]",
                          type=argparse.FileType('w'),
                          default='-')
   imgParser.add_argument('--spec', help="Object spec dictionary (JSON)",
                          type=json.loads, required=True)
   imgParser.add_argument('--validate', help="Validates image profile",
                          action='store_true')
   imgParser.add_argument('--bulletin', help="Bulletin files to include",
                          type=argparse.FileType('r'),
                          nargs="*")
   imgParser.add_argument('--baseimage', help="Base image to include",
                          type=argparse.FileType('r'))
   imgParser.add_argument('--addon', help="AddOn to include",
                          type=argparse.FileType('r'))
   imgParser.set_defaults(func=imageProfile)

   vibParser = subparsers.add_parser('vib', help='vib help')
   vibParser.add_argument('--output', help="VIB output filename", required=True)
   vibParser.add_argument('--spec', help="VIB attribute spec dictionary (JSON)",
                          type=json.loads, required=True)
   vibParser.add_argument('--payload', help="Payload attribute tuple",
                          action="append")
   vibParser.add_argument('--objcopy', help="objcopy binary path for txt-mle")
   vibParser.add_argument('--tmpDir', help="temp dir for xz decompress and vib "
                                           "signing")
   vibParser.add_argument('--xz', help="xz binary path for decompress")
   vibParser.add_argument('--keyid', help="Signc keyid to sign the VIB",
                          action="append")
   vibParser.set_defaults(func=vib)

   baseImgParser = subparsers.add_parser('baseImage', help='base image help')
   baseImgParser.add_argument('components', help="Component files to include",
                              type=argparse.FileType('r'),
                              nargs="+")
   baseImgParser.add_argument('--imageSpec', type=json.loads, required=True,
                              help="Object spec dictionary (JSON)")
   baseImgParser.add_argument('--output', help="Output filename [stdout]",
                              type=argparse.FileType('w'), default='-')
   baseImgParser.add_argument('--validate', help="Validates base image",
                              action='store_true')
   baseImgParser.set_defaults(func=baseImage)

   addonParser = subparsers.add_parser('addon', help='addon help')
   addonParser.add_argument('components', help="Component files to include",
                            type=argparse.FileType('r'), nargs="*")
   addonParser.add_argument('--removedComponents',
                            help="Component files to include",
                            type=argparse.FileType('r'), nargs="*")
   addonParser.add_argument('--addonSpec', type=json.loads, required=True,
                            help="Object spec dictionary (JSON)")
   addonParser.add_argument('--output', help="Output filename [stdout]",
                            type=argparse.FileType('w'), default='-')
   addonParser.add_argument('--validate', help="Validates addon",
                            action='store_true')
   addonParser.set_defaults(func=addon)

   softwareSpecToImageProfiles = subparsers.add_parser('softwareSpec2Ip',
                                                       help='software specification to IP help')
   softwareSpecToImageProfiles.add_argument('--softwareSpec', required=True,
                                            help="Software Specification File")

   softwareSpecToImageProfiles.add_argument('--depot', required=True,
                                            help="depot")
   softwareSpecToImageProfiles.add_argument('--output',  help="Output filename [stdout]",
                                            type=argparse.FileType('w'), default='-')
   softwareSpecToImageProfiles.set_defaults(func=softwareSpec2IP)

   args = parser.parse_args()

   # Useful for debugging...
   # print(vars(args))

   args.func(args)

if __name__ == "__main__":
   main()
