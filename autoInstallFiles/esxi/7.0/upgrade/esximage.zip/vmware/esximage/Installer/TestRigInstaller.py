#!/usr/bin/python
########################################################################
# Copyright (C) 2010 VMWare, Inc.                                      #
# All Rights Reserved                                                  #
########################################################################

import Installer

class TestRigInstaller(Installer.Installer):
   pass
