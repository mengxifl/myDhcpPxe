#!/usr/bin/python
########################################################################
# Copyright (C) 2010 VMWare, Inc.                                      #
# All Rights Reserved                                                  #
########################################################################

import Installer

class IsoImageInstaller(Installer.Installer):
   pass
