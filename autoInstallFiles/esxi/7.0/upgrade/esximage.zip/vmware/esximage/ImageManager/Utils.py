# Copyright 2019 VMware, Inc.
# All rights reserved. -- VMware Confidential

"""Utilities for ImageManager VAPI.
"""

from datetime import datetime

from . import Constants

# Python datetime format that is the closest to, but not exactly matching vAPI's
# definition. See vapi-core/vapi/DateTime.cpp for the full format.
# str2Time() and time2Str() need to be used to convert from/to vAPI's format.
BASE_TASK_TIME_FORMAT = '%Y-%m-%dT%H:%M:%S.%f'

# Get a list of object.toDict() result for each object in the non-empty list.
# Otherwise simply return None.
getOptionalDictList = lambda x: [i.toDict() for i in x] if x else None

class Notification(object):
   """A class that represents one VAPI notification.
      See com.vmware.esx.settings_daemon.Notifications.
   """
   def __init__(self, notificationId, msgId, msg, resMsgId, resMsg,
                msgArgs=None, resArgs=None):
      self.notificationId = notificationId
      self.msgId = msgId
      self.msg = msg
      self.msgArgs = msgArgs or []
      self.resMsgId = resMsgId
      self.resMsg = resMsg
      self.resArgs = resArgs or []
      self.time = datetime.utcnow()

   def toDict(self):
      msg = dict(id=self.msgId,
                 default_message=self.msg,
                 args=self.msgArgs)
      if self.resMsgId or self.resMsg or self.resArgs:
         # Resolution is optional.
         resolution = dict(id=self.resMsgId,
                           default_message=self.resMsg,
                           args=self.resArgs)
      else:
         resolution = None
      return dict(id=self.notificationId,
                  message=msg,
                  resolution=resolution,
                  time=time2Str(self.time))

class Notifications(object):
   """A collection of notifications divided to info, warning and error
      categories.
      See com.vmware.esx.settings_daemon.Notifications.
   """
   def __init__(self, infoMsgs=None, warnMsgs=None, errMsgs=None):
      self.info = infoMsgs or []
      self.warnings = warnMsgs or []
      self.errors = errMsgs or []

   def toDict(self):
      return dict(info=getOptionalDictList(self.info),
                  warnings=getOptionalDictList(self.warnings),
                  errors=getOptionalDictList(self.errors))

def time2Str(timeObj):
   """Convert datetime object to a VAPI time string.
   """
   # Truncate microsec to millisec and add Z.
   return timeObj.strftime(BASE_TASK_TIME_FORMAT)[:-3] + 'Z'

def getExceptionNotification(ex):
   """Get a notification from an exception.
   """
   if hasattr(ex, 'cause') and ex.cause is not None:
      # Nested exception, get notification from the actual error if given.
      ex = ex.cause

   # Error name is figured using an alias map and the conversion map.
   # UnknownError is assigned for an error that is not explicitly
   # handled.
   exType = type(ex).__name__
   errorAlias = Constants.ESXIMAGE_ERROR_ALIAS.get(exType, exType)
   errorName = (errorAlias if errorAlias in Constants.ESXIMAGE_ERROR_MSG_ARG
                else 'UnknownError')
   notifId = Constants.ESXIMAGE_PREFIX + errorName
   msg, argNames = Constants.ESXIMAGE_ERROR_MSG_ARG[errorName]

   # Get arguments for the notification by attributes in the exception
   # object.
   msgArgs = []
   for arg in argNames:
      attr = getattr(ex, arg)
      if isinstance(attr, list):
         msgArgs.append(','.join(attr))
      else:
         msgArgs.append(str(attr))

   # For error reporting, resolution is not used.
   return Notification(notifId, notifId, msg, "", "", msgArgs=msgArgs)
