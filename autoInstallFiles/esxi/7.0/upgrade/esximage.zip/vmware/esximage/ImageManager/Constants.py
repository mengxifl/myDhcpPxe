# Copyright 2019 VMware, Inc.
# All rights reserved. -- VMware Confidential

"""Constants
Constants that are used in the ImageManager.
"""

# Scanner Constants
# Status
COMPLIANT = "COMPLIANT"
NON_COMPLIANT = "NON_COMPLIANT"
INCOMPATIBLE = "INCOMPATIBLE"
UNAVAILABLE = "UNAVAILABLE"

# Impact types and messages.
IMPACT_NONE = "NO_IMPACT"
IMPACT_MMODE = "MAINTENANCE_MODE_REQUIRED"
IMPACT_REBOOT = "REBOOT_REQUIRED"

# Component source, see SoftwareInfo.vmodl.
SOURCE_BASEIMAGE = "BASE_IMAGE"
SOURCE_ADDON = "ADD_ON"
SOURCE_HSP = "HARDWARE_SUPPORT_PACKAGE"
SOURCE_USER = "USER"

# Result Structure Params
DISP_VERSION = "display_version"
DISP_NAME = "display_name"
VERSION = "version"
VENDOR = "vendor"
BASE_IMG = "base_image"
BASEIMAGE_UI_NAME = "ESXi"
ADD_ON = "add_on"
COMPONENTS = "components"
HARDWARE_SUPPORT = "hardware_support"
SOLUTIONS = "solutions"

# Notification ID and messages.
HOSTSCAN_PREFIX = "com.vmware.vcIntegrity.lifecycle.HostScan."
RESOLUTION_SUFFIX = ".Resolution"

UNAVAILABLE_ID = HOSTSCAN_PREFIX + "Unavailable"

BASEIMAGE_DOWNGRADE_ID = HOSTSCAN_PREFIX + "BaseImageDowngrade"
ADDON_DOWNGRADE_ID = HOSTSCAN_PREFIX + "AddonDowngrade"
RM_ADDON_COMP_DOWNGRADE_ID = HOSTSCAN_PREFIX + "RemovedAddonComponentDowngrade"
COMPONENT_DOWNGRADE_ID = HOSTSCAN_PREFIX + "ComponentDowngrade"
HSP_DOWNGRADE_ID = HOSTSCAN_PREFIX + "HSPDowngrade"
HSP_COMP_HSP_DOWNGRADE_ID = HOSTSCAN_PREFIX + "HSPCompHSPDowngrade"
RM_HSP_COMP_ADDON_DOWNGRADE_ID = HOSTSCAN_PREFIX + \
                                                "RemovedHSPCompAddonDowngrade"
RM_HSP_COMP_BASEIMAGE_DOWNGRADE_ID = HOSTSCAN_PREFIX + \
                                             "RemovedHSPCompBaseImageDowngrade"
SOLUTION_DOWNGRADE_ID = HOSTSCAN_PREFIX + "SolutionDowngrade"
SOLUTIONCOMPONENT_DOWNGRADE_ID = HOSTSCAN_PREFIX + "SolutionComponentDowngrade"
VIB_DOWNGRADE_ID = HOSTSCAN_PREFIX + "VibDowngrade"

ADDON_REMOVAL_ID = HOSTSCAN_PREFIX + "AddonRemoval"
COMPONENT_REMOVAL_ID = HOSTSCAN_PREFIX + "ComponentRemoval"
HSP_REMOVAL_ID = HOSTSCAN_PREFIX + "HSPRemoval"
SOLUTIONCOMPONENT_REMOVAL_ID = HOSTSCAN_PREFIX + "SolutionComponentRemoval"
VIB_REMOVAL_ID = HOSTSCAN_PREFIX + "VibRemoval"

SOLUTION_DISABLE_ID = HOSTSCAN_PREFIX + "SolutionDisable"
SOLUTION_ENABLE_ID = HOSTSCAN_PREFIX + "SolutionEnable"

BASEIMAGE_COMPONENT_REMOVED_ID = HOSTSCAN_PREFIX + "BaseImageComponentRemoved"
ADDON_COMPONENT_REMOVED_ID = HOSTSCAN_PREFIX + "AddonComponentRemoved"
HSP_COMPONENT_REMOVED_ID = HOSTSCAN_PREFIX + "HSPComponentRemoved"

MAINTMODE_IMPACT_ID = HOSTSCAN_PREFIX + "MaintenanceModeImpact"
REBOOT_IMPACT_ID = HOSTSCAN_PREFIX + "RebootImpact"
PENDING_REBOOT_ID = HOSTSCAN_PREFIX + "PendingReboot"

INSUFFICIENT_MEMORY_ID = HOSTSCAN_PREFIX + "InsufficientMemory"
UNSUPPORTED_CPU_ID = HOSTSCAN_PREFIX + "UnsupportedCpu"
NOT_ENOUGH_CPU_CORE_ID = HOSTSCAN_PREFIX + "NotEnoughCpuCore"
UNSUPPORTED_PCI_DEVICE = HOSTSCAN_PREFIX + "UnsupportedPciDevice"
# Unsupported Model or Vendor
UNSUPPORTED_VENDOR_MODEL_ID = HOSTSCAN_PREFIX + "Unsupported%s"
NO_NIC_DRIVER_ID = HOSTSCAN_PREFIX + "NoNicDriver"
NO_BOOTDEVICE_DRIVER_ID = HOSTSCAN_PREFIX + "NoBootDeviceDriver"
INSUFFICIENT_BOOTBANK_SPACE_ID = HOSTSCAN_PREFIX + "InsufficientBootBankSpace"
INSUFFICIENT_LOCKER_SPACE_ID = HOSTSCAN_PREFIX + "InsufficientLockerSpace"
DISK_TOO_SMALL_ID = HOSTSCAN_PREFIX + "DiskTooSmall"
HOST_ACCEPTANCE_ID = HOSTSCAN_PREFIX + "HostAcceptance"

# Error message IDs, default messages and arguments.
ESXIMAGE_PREFIX = "com.vmware.vcIntegrity.lifecycle.EsxImage."

#  Usually the name of the exeption will be the key in APPLY_EXCEPTION_MSG_ARG,
#  here aliases are included to convert an exception.
ESXIMAGE_ERROR_ALIAS = {
   # Profile validation contains a few other checks, but generally it is
   # correct to say the components have validation issues.
   "ProfileValidationError": "ComponentValidationError",
}

NOTIFICATION_MSG = {
   UNAVAILABLE_ID: "Host scan task failed with an unknown error.",
   BASEIMAGE_DOWNGRADE_ID: "Desired Base Image version {1} is a downgrade of " \
      "the installed version {2}.",
   ADDON_DOWNGRADE_ID: "Desired version {1} of Addon {2} is a downgrade of " \
      "the installed version {3}.",
   RM_ADDON_COMP_DOWNGRADE_ID: "Version {1} of Component {2} in the desired " \
      "Base Image is a downgrade of version {3} in the current installed " \
      "Addon.",
   HSP_DOWNGRADE_ID: "Desired version {1} of Hardware Support Package {2} " \
      "is a downgrade of the installed version {3}.",
   HSP_COMP_HSP_DOWNGRADE_ID: "Components {1} of Hardware Support Package " \
      "{2} version {3} downgrade other Hardware Support Package(s).",
   RM_HSP_COMP_ADDON_DOWNGRADE_ID:  "Base Image in the desired spec " \
      "downgrades Components {1} of Hardware Support Package {2} version " \
      "{3} that is pending removal.",
   RM_HSP_COMP_BASEIMAGE_DOWNGRADE_ID: "Addon in the desired spec downgrades " \
      "Components {1} of Hardware Support Package {2} version {3} that is " \
      "pending removal.",
   COMPONENT_DOWNGRADE_ID: "Desired version {1} of Component {2} is a " \
      "downgrade of the installed version {3}.",
   SOLUTION_DOWNGRADE_ID: "Desired version {1} of Solution {2} is a " \
      "downgrade of the installed version {3}.",
   SOLUTIONCOMPONENT_DOWNGRADE_ID: "Components {1} in Solution {2} are " \
      "either missing or downgraded on the host.",
   VIB_DOWNGRADE_ID: "VIBs {1} on the host are downgraded in the desired " \
      "state.",
   ADDON_REMOVAL_ID: "Addon {1} with version {2} is removed in the desired " \
                     "state. It will be removed during remediation.",
   HSP_REMOVAL_ID: "Hardware Support Package {1} with version {2} is " \
      "removed in the desired state. It will be removed during remediation.",
   COMPONENT_REMOVAL_ID: "Components {1} are removed in the desired state. " \
      "They will be removed during remediation.",
   SOLUTIONCOMPONENT_REMOVAL_ID: "Components {1} in Solution {2} are removed " \
      "in the desired state. They will be removed during remediation.",
   VIB_REMOVAL_ID: "The following vibs on the host are missing from the " \
      "image and will be removed upon remediating: {1}.",

   SOLUTION_DISABLE_ID: "Solution components of disabled solutions {1} will " \
                        "be removed from this host during remediation.",
   SOLUTION_ENABLE_ID: "Remediating this host will enable these solutions: " \
                       "{1}.",

   BASEIMAGE_COMPONENT_REMOVED_ID: "Base Image Components {1} are either " \
      "missing or downgraded on the host. Appropriate action will be taken " \
      "during remediation.",
   ADDON_COMPONENT_REMOVED_ID: "Addon Components {1} are either missing or " \
      "downgraded on the host. Appropriate action will be taken during " \
      "remediation.",
   HSP_COMPONENT_REMOVED_ID: "Hardware Support Package Components {1} are " \
      "either missing or downgraded on the host. The correct versions of " \
      "the Components will be installed during remediation.",

   MAINTMODE_IMPACT_ID: "The host will be placed in maintenance mode before " \
      "remediation.",
   REBOOT_IMPACT_ID: "The host will be rebooted during remediation.",
   PENDING_REBOOT_ID: "The host is pending a reboot since a previous " \
                      "software change. The pending change is not reflected " \
                      "in host's current state in the compliance results " \
                      "below. Reboot the host to see accurate compliance " \
                      "results.",

   INSUFFICIENT_MEMORY_ID: "The host has {1} MB of memory, a minimum of {2} " \
      "MB is required by the desired state.",
   UNSUPPORTED_CPU_ID: "The CPU on the host is not supported by the desired " \
      "state.",
   NOT_ENOUGH_CPU_CORE_ID: "The CPU on the host has {1} cores, a minimum of " \
      "{2} cores are required by the desired state.",
   UNSUPPORTED_PCI_DEVICE: "Unsupported PCI devices {1} found on the host.",
   UNSUPPORTED_VENDOR_MODEL_ID % 'Vendor': "Host hardware vendor {1} is not " \
      "supported by the desired state.",
   UNSUPPORTED_VENDOR_MODEL_ID % 'Model': "Host hardware model {1} is not " \
      "supported by the desired state.",
   NO_NIC_DRIVER_ID: "The management NIC of the host lacks a driver in the " \
      "desired state.",
   NO_BOOTDEVICE_DRIVER_ID: "The boot device of the host lacks a driver in " \
      "the desired state.",
   INSUFFICIENT_BOOTBANK_SPACE_ID: "The bootbank partition on the host has a " \
      "capacity of {1} MB, the desired state requires {2} MB.",
   INSUFFICIENT_LOCKER_SPACE_ID: "The locker partition on the host has {1} " \
      "MB free space available, the desired state requires {2} MB.",
   DISK_TOO_SMALL_ID: "The boot device of the host has a capacity of {1} MB, " \
      "a minimum of {2} MB is required by the desired state.",
   HOST_ACCEPTANCE_ID: "Acceptance level of the desired state is not " \
      "compatible with the host's configured setting.",
   }

#  Map from name of exception to default message and arguments to extract from
#  the exception.
ESXIMAGE_ERROR_MSG_ARG = {
   "AcceptanceConfigError": ("A VIB package cannot be installed due to the "
                             "current host acceptance level configuration.",
                             []),
   "AcceptanceGetError": ("Failed to get the current host acceptance level "
                          "configuration.",
                          []),
   "AddonBaseImageMismatchError": ("Addon {1} is incompatible with base "
                                   "image version {2}.",
                                   ["addonId", "baseImageVersion"]),
   "AddonNotFound": ("Addon {1} with version {2} cannot be found in depot.",
                     ["name", "version"]),
   "AddonValidationError": ("Failed to validate metadata or components of " \
                            "addon {1}.",
                            ['addonID']),
   "BaseImageNotFound": ("The Base Image with version {1} cannot be found in "
                         "depot.",
                         ["version"]),
   "BaseimageValidationError": ("Failed to validate metadata or components " \
                                "of the base image.",
                                []),
   "ComponentDowngradeError": ("The operation cannot continue due to downgrade "
                               "of the following Components: {1}.",
                               ["components"]),
   "ComponentFormatError": ("An error occurred while parsing or merging "
                            "components.",
                            []),
   "ComponentNotFoundError": ("Component {1} cannot be found in depot.",
                              ["name"]),
   "ComponentValidationError": ("There are Compoment relation and content "
                                "problems with the desired state.",
                                []),
   "DatabaseIOError": ("Cannot read or write the image database on the host.",
                       []),
   "DatabaseFormatError": ("The image database on the host is invalid or "
                           "corrupted.",
                           []),
   "DepotConnectError": ("An error occurred while connecting to depot.",
                         []),
   "HardwareSupportPackageNotFound": (
      "Manifest with Hardware Support Manager {1} and Hardware Support "
      "Package {2} version {3} cannot be found in depot.",
      ["manager", "package", "version"]),
   "InstallationError": ("A runtime error occurred while remediating the host.",
                         []),
   "LiveInstallationError": ("An error occurred while performing live system "
                             "changes during the remediation.",
                             []),
   "LockingError": ("Remediation cannot begin because another process is "
                    "updating the host.",
                    []),
   "MaintenanceModeError": ("Maintenance mode is either not enabled or cannot "
                            "be determined on the host.",
                            []),
   "ManifestBaseImageMismatchError": (
      "Manifest with Hardware Support Manager {1} and Hardware Support "
      "Package {2} version {3} does not support Base Image version {4}.",
      ["manager", "package", "version", "baseImageVersion"]),
   "MetadataDownloadError": ("An error occurred while downloading depot "
                             "metadata from {1}.",
                             ['url']),
   "MetadataFormatError": ("The format of metadata in {1} is invalid.",
                           ['filename']),
   "MetadataIOError": ("An error occured while reading metadata.zip.",
                       []),
   "MissingComponentError": ("Cannot find metadata for a Component.",
                             []),
   "MissingVibError": ("Cannot find metadata for VIB(s) {1} in database or "
                       "depot.",
                       ["vibIDs"]),
   "MultipleManifestError": (
      "The current version of ESXi does not support multiple Hardware Support "
      "Packages.",
      []),
   "ReleaseUnitConflictError": ("There are unequal Base Images, Addons or "
                                "Solutions metadata that share the "
                                "same ID {1}.",
                                ['releaseID']),
   "SoftwareSpecFormatError": ("Corrputed or invalid software specification "
                               "format. Missing attribute: {1}.",
                               ['field']),
   "SolutionComponentNotFound": ("Component {1} within software Solution {2} "
                                 "cannot be found in depot.",
                                 ["component", "solution"]),
   "SolutionNotFound": ("Software Solution {1} with version {2} cannot be "
                        "found in depot.",
                        ["name", "version"]),
   "VibCertStoreError": ("Failed to import certificates or revocation lists "
                         "while verifying VIB signature.",
                         []),
   "VibDownloadError": ("An error occurred while downloading VIB from URL {1}.",
                        ['url']),
   "VibFormatError": ("The format of VIB {1} is invalid.",
                      ['filename']),
   "VibSigDigestError": ("Signature of VIB {1} cannot be verified against its "
                         "contents.",
                         ['vib']),
   "VibSigFormatError": ("VIB {1} contains an invalid or corrupted signature.",
                         ['vib']),
   "VibSigInvalidError": ("VIB {1} contains an invalid or corrupted signature.",
                          ['vib']),
   "VibSigMissingError": ("VIB {1} does not have a signature and thus cannot "
                          "be verified.",
                          ['vib']),
   # Catch-all unknown error message that need to be used when the type is not
   # listed above.
   "UnknownError": ("An unknown error occurred while performing the operation.",
                    []),
   }

# Resolution messages, indexed by notification/message IDs.
RESOLUTION_MSG = {
   UNAVAILABLE_ID: "Retry the scan operation at a later time.",
   BASEIMAGE_DOWNGRADE_ID: "Replace the Base Image in the desired state with " \
      "one of the same or higher version.",
   ADDON_DOWNGRADE_ID: "Replace the Addon in the desired state with one of " \
      "the same or higher version.",
   RM_ADDON_COMP_DOWNGRADE_ID: "Add the Component with matching or higher " \
                               "version as currently installed to the " \
                               "desired state.",
   HSP_DOWNGRADE_ID: "Select a matching or higher version of Hardware " \
                     "Support Package.",
   HSP_COMP_HSP_DOWNGRADE_ID: "Select a Hardware Support Package that " \
      "contains Components with matching or higher versions.",
   RM_HSP_COMP_ADDON_DOWNGRADE_ID: "Add a matching or higher version of the " \
      "currently installed component to the desired state.",
   RM_HSP_COMP_BASEIMAGE_DOWNGRADE_ID: "Add a matching or higher version of " \
      "the currently installed component to the desired state.",
   COMPONENT_DOWNGRADE_ID: "Replace the Component in the desired state with " \
      "one of the same or higher version.",
   SOLUTION_DOWNGRADE_ID: "Upgrade the version of Solution enabled on the " \
      "host.",
   SOLUTIONCOMPONENT_DOWNGRADE_ID: "Upgrade the version of Solution enabled " \
      "on the host.",
   VIB_DOWNGRADE_ID: "Add Addon and Components that include matching or " \
      "higher version VIBs to the desired state.",

   ADDON_REMOVAL_ID: "Add the Addon to the desired state to retain it.",
   COMPONENT_REMOVAL_ID: "Add the Components to the desired state to retain " \
      "them.",
   HSP_REMOVAL_ID: "Enable the corresponding Hardware Support Manager to " \
                   "retain the package.",
   SOLUTIONCOMPONENT_REMOVAL_ID: "Enable corresponding functionalities of " \
      "the Solution to add the Components back to the desired state.",
   VIB_REMOVAL_ID: "To prevent them from being removed, include appropriate " \
      "components that are equivalent to these vibs.",

   SOLUTION_DISABLE_ID: "",
   SOLUTION_ENABLE_ID: "",

   BASEIMAGE_COMPONENT_REMOVED_ID: "",
   ADDON_COMPONENT_REMOVED_ID: "",
   HSP_COMPONENT_REMOVED_ID: "",

   MAINTMODE_IMPACT_ID: "",
   REBOOT_IMPACT_ID: "",
   PENDING_REBOOT_ID: "",

   INSUFFICIENT_MEMORY_ID: "",
   UNSUPPORTED_CPU_ID: "",
   NOT_ENOUGH_CPU_CORE_ID: "",
   UNSUPPORTED_PCI_DEVICE: "",
   UNSUPPORTED_VENDOR_MODEL_ID % 'Vendor': "Replace Addon or Components that " \
      "are released for a different hardware vendor.",
   UNSUPPORTED_VENDOR_MODEL_ID % 'Model': "Replace Addon or Components that " \
      "are released for a different hardware model.",
   NO_NIC_DRIVER_ID: "Make sure the desired state contains the appropriate " \
      "driver for the management NIC.",
   NO_BOOTDEVICE_DRIVER_ID: "Make sure the desired state contains the " \
      "appropriate driver for the boot device.",
   INSUFFICIENT_BOOTBANK_SPACE_ID: "Remove unnecessary Components from " \
      "the desired state.",
   INSUFFICIENT_LOCKER_SPACE_ID: "Cleanup the locker partition on the host, " \
      "and retry the scan operation.",
   DISK_TOO_SMALL_ID: "",
   HOST_ACCEPTANCE_ID: "Make sure the host is configured at an appropriate " \
      "acceptance level for the desired state, and retry the scan operation.",
   }

# Map from precheck result name to notification ID.
PRECHECK_NOTIFICATION_ID = {
   "MEMORY_SIZE": INSUFFICIENT_MEMORY_ID,
   "CPU_SUPPORT": UNSUPPORTED_CPU_ID,
   "CPU_CORES": NOT_ENOUGH_CPU_CORE_ID,
   "UNSUPPORTED_DEVICES": UNSUPPORTED_PCI_DEVICE,
   "VALIDATE_HOST_HW": UNSUPPORTED_VENDOR_MODEL_ID,
   "NATIVE_BOOT_NIC": NO_NIC_DRIVER_ID,
   "NATIVE_BOOTBANK": NO_BOOTDEVICE_DRIVER_ID,
   "IMAGEPROFILE_SIZE": INSUFFICIENT_BOOTBANK_SPACE_ID,
   "LOCKER_SPACE_AVAIL": INSUFFICIENT_LOCKER_SPACE_ID,
   "BOOT_DISK_SIZE": DISK_TOO_SMALL_ID,
   "HOST_ACCEPTANCE": HOST_ACCEPTANCE_ID,
   }

# Image entities.
BASE_IMAGE = "base_image"
ADDON = "addon"
COMPONENT = "component"
SOLUTION = "solution"
SOLUTION_COMPONENT = "solution_component"
OLD_ADDON_COMP = "old_addon_component"

# Map from downgrade entity to notification ID.
DOWNGRADE_NOTIFICATION_ID = {
   BASE_IMAGE: BASEIMAGE_DOWNGRADE_ID,
   ADDON: ADDON_DOWNGRADE_ID,
   COMPONENT: COMPONENT_DOWNGRADE_ID,
   HARDWARE_SUPPORT: HSP_DOWNGRADE_ID,
   SOLUTION: SOLUTION_DOWNGRADE_ID,
   SOLUTION_COMPONENT: SOLUTIONCOMPONENT_DOWNGRADE_ID,
   OLD_ADDON_COMP: RM_ADDON_COMP_DOWNGRADE_ID
   }

# Image profile scan spec.
BASEIMAGE_COMPS_KEY = "base_image_components"
ADDON_COMPS_KEY = "addon_components"
USER_COMPS_KEY = "user_components"
REMOVED_DG_BI_COMP_KEY = "removed_or_downgraded_bi_components"
REMOVED_DG_ADDON_COMP_KEY = "removed_or_downgraded_add_on_components"
ORPHAN_VIBS = 'orphan_vibs'

# Validate software spec entities.
VALIDATE_PREFIX = 'com.vmware.vcIntegrity.lifecycle.Validate.'
VALIDATE_SUCCESS_ID = VALIDATE_PREFIX + 'Success'
VALIDATE_SUCCESS_MSG = 'The image is valid.'

# Depot metadata schema validation entities
DEPOT_METADATA_SCHEMA_VALIDATE_SUCCESS_MSG = \
           'Depot validation succeeded.'
