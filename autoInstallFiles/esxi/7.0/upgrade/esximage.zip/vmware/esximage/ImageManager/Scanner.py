# Copyright 2019 VMware, Inc.
# All rights reserved. -- VMware Confidential

"""Scanner
Implementation of host scan against the desired software spec.
"""

import json
import logging
import os
import sys
import traceback

from datetime import datetime

from com.vmware.esx.settings_daemon_client \
   import (AddOnCompliance, AddOnDetails, AddOnInfo, BaseImageCompliance,
           BaseImageDetails, BaseImageInfo, ComplianceImpact, ComplianceStatus,
           ComponentCompliance, ComponentDetails, ComponentInfo,
           ComponentSource, HardwareSupportPackageCompliance,
           HardwareSupportPackageInfo, HostCompliance, Notification,
           Notifications, SolutionCompliance, SolutionDetails,
           SolutionComponentDetails, SolutionComponentSpec, SolutionInfo)
from com.vmware.vapi.std_client import LocalizableMessage
from vmware.vapi.bindings.converter import TypeConverter
from vmware.vapi.data.serializers.jsonrpc import VAPIJsonEncoder

from .Constants import *
from .DepotMgr import DepotMgr
from .SoftwareSpecMgr import SoftwareSpecMgr
from .Utils import getExceptionNotification

from ..Bulletin import ComponentCollection
from ..Errors import InstallerNotAppropriate
from ..HostImage import HostImage
from ..Version import VibVersion
from ..VibCollection import VibCollection
from ..Utils.HostInfo import HostOSIsSimulator

SCAN_TASK_ID = 'com.vmware.esx.settingsdaemon.software.scan'

isNotNone = lambda x: x is not None
# Adapt an object or a list to an optional value where None is
# written when unset/empty.
getOptionalVal = lambda x: x if x else None

def vapiStructToJson(struct):
   """Convert a VAPI struct class object to JSON RPC.
   """
   dataValue = TypeConverter.convert_to_vapi(struct,
                                             type(struct).get_binding_type())

   return json.dumps(dataValue,
                     check_circular=False,
                     separators=(',', ':'),
                     cls=VAPIJsonEncoder)

def getNotification(notificationId, msgId, msgArgs=None, resArgs=None):
   msg = LocalizableMessage(id=msgId, default_message=NOTIFICATION_MSG[msgId],
                            args=msgArgs or [])
   resMsg = LocalizableMessage(id=msgId + RESOLUTION_SUFFIX,
                               default_message=RESOLUTION_MSG[notificationId],
                               args=resArgs or [])
   return Notification(id=notificationId,
                       time=datetime.utcnow(),
                       message=msg,
                       resolution=resMsg)

def getBaseImageInfo(displayName, version, displayVersion, releaseDate):
   details = BaseImageDetails(display_name=displayName,
                              display_version=displayVersion or version,
                              release_date=releaseDate)
   return BaseImageInfo(details=details, version=version)

def getAddOnInfo(name, displayName, version, displayVersion, vendor):
   details = AddOnDetails(display_name=displayName or name,
                          vendor=vendor,
                          display_version=displayVersion or version)
   return AddOnInfo(details=details, name=name, version=version)

def getComponentInfo(displayName, version, displayVersion, vendor):
   details = ComponentDetails(display_name=displayName,
                              vendor=vendor,
                              display_version=displayVersion)
   return ComponentInfo(version=version, details=details)

def getVersionCompliance(desiredVerStr, currentVerStr, entityName, entityType):
   """Compare desired and current version string and return a tuple of
      compliance result and a notification message struct for incompatible
      result.
   """
   desiredVersion = VibVersion.fromstring(desiredVerStr)
   currentVersion = VibVersion.fromstring(currentVerStr)
   if desiredVersion > currentVersion:
      return NON_COMPLIANT, None
   elif desiredVersion < currentVersion:
      notiId = DOWNGRADE_NOTIFICATION_ID[entityType]
      # Base image does not need name in the argument list.
      msgArgs = ([desiredVerStr, currentVerStr] if entityType == BASE_IMAGE
                 else [desiredVerStr, entityName, currentVerStr])
      msgArgs = [desiredVerStr, entityName, currentVerStr]
      msgDict = getNotification(notiId, notiId, msgArgs=msgArgs)
      return INCOMPATIBLE, msgDict
   else:
      return COMPLIANT, None

def getImageProfileImpact(hostImg, imgProfile):
   """Get the impact of the target image profile, could be one of: no impact,
      maintenance mode required, and reboot required (implies maintenance
      mode required).
      The calculation is VIB based where reboot, overlay and mmode metadata
      are available.
      Returns the impact and a boolean indicating if the host is pending reboot
      from a previous software change, which automatically cause a reboot
      required impact.
   """
   if not 'live' in hostImg.installers:
      raise InstallerNotAppropriate('live', 'Live installer is not operational')

   # LiveImageInstaller gives Nones (unsupported) when reboot is required:
   # 1. The host is already pending a reboot.
   # 2. VIB removed or VIB installed requires reboot.
   # 3. The transaction involves an change in overlay file.
   liveInstaller = hostImg.installers['live']
   adds, removes, _ = liveInstaller.StartTransaction(
                                                imgProfile,
                                                hostImg.imgstate,
                                                preparedest=False)
   rebootRequired = (adds == removes == None)
   if rebootRequired:
      # When the image state is bootbank updated, we have a pending reboot.
      return (IMPACT_REBOOT,
              hostImg.imgstate == hostImg.IMGSTATE_BOOTBANK_UPDATED)

   # Check if live VIB removal/addition requires maintenance mode.
   mmoderemoves, mmodeadds = \
         liveInstaller.liveimage.GetMaintenanceModeVibs(imgProfile.vibs,
                                                        adds,
                                                        removes)
   if mmoderemoves or mmodeadds:
      return IMPACT_MMODE, False

   return IMPACT_NONE, False

def getSolutionInfo(solution, components):
   """Form a SolutionInfo object from a Solution object and components.
   """
   solComps = solution.MatchComponents(components)
   compDetails = list()
   if solComps:
      for comps in solComps.values():
         assert len(comps) == 1
         comp = comps[0]
         solComp = SolutionComponentDetails(
                           component=comp.compNameStr,
                           display_name=comp.compNameUiStr,
                           display_version=comp.compVersionUiStr,
                           vendor=comp.vendor)
         compDetails.append(solComp)

   solDetails = SolutionDetails(display_name=solution.nameSpec.uiString,
                                display_version=solution.versionSpec.uiString,
                                components=compDetails)

   return SolutionInfo(details=solDetails,
                       version=solution.versionSpec.version.versionstring,
                       components=[SolutionComponentSpec(component=d.component)
                                   for d in compDetails])

def getHardwareSupportCompliance(status, curManifest, targetManifest,
                                 notifications):
   """For hardware support compliance object from the computed status,
      two manifest objects and notifications.
   """
   def _getOptionalInfo(manifest):
      if isNotNone(manifest):
         return HardwareSupportPackageInfo(
                  pkg=manifest.hardwareSupportInfo.package.name,
                  version=manifest.hardwareSupportInfo.package.version)
      else:
         return None

   assert curManifest or targetManifest
   curInfo = _getOptionalInfo(curManifest)
   targetInfo = _getOptionalInfo(targetManifest)
   notifications = notifications or Notifications()

   return HardwareSupportPackageCompliance(status=ComplianceStatus(status),
                                           current=curInfo,
                                           target=targetInfo,
                                           hardware_modules=dict(),
                                           notifications=notifications)

class HostScanner(object):
   """Host scanner.

   Scan the host compliance based on the desired software spec.
   """

   def __init__(self, swSpec, depotSpec, task):
      """Constructor.
      """
      self.swSpec = swSpec
      self.depotSpec = depotSpec
      # Task should have been already started.
      self.task = task

      self.hostImage = None
      self.hostImageProfile = None
      self.currentSoftwareScanSpec = None
      self.desiredImageProfile = None
      self.overallNotifications = None

   def _formUnavailableResult(self, errMsg):
      """Form unavailable host compliance scan result.
      """
      errMsg = getNotification(UNAVAILABLE_ID,
                               UNAVAILABLE_ID)
      self.overallNotifications.errors.append(errMsg)

      baseImageInfo = getBaseImageInfo('', '', '', datetime.utcnow())
      baseImage = BaseImageCompliance(status=ComplianceStatus(UNAVAILABLE),
                                      current=baseImageInfo,
                                      target=baseImageInfo,
                                      notifications=Notifications())
      addOn = AddOnCompliance(status=ComplianceStatus(UNAVAILABLE),
                              notifications=Notifications())

      # Re-process all notification lists to use optional when applicable.
      notifications = Notifications(
                  info=getOptionalVal(self.overallNotifications.info),
                  warnings=getOptionalVal(self.overallNotifications.warnings),
                  errors=getOptionalVal(self.overallNotifications.errors))

      return HostCompliance(impact=ComplianceImpact(IMPACT_NONE),
                            status=ComplianceStatus(UNAVAILABLE),
                            notifications=notifications,
                            scan_time=datetime.utcnow(),
                            base_image=baseImage,
                            add_on=addOn,
                            hardware_support=dict(),
                            components=dict(),
                            solutions=dict())

   def reportErrorResult(self, errMsg, ex):
      """Form compliance result for an error from a general error message
         and an exception.
      """
      # Log error message and trace.
      logMsg = '%s: %s' % (errMsg, str(ex))
      logging.error(logMsg)
      logging.error(traceback.format_exc())
      unavalCompliance = self._formUnavailableResult(errMsg)
      self.task.failTask(error=getExceptionNotification(ex),
                         result=vapiStructToJson(unavalCompliance))

      # XXX Need to be exception based, revisit it when changing the CLI
      # interfaces.
      sys.exit(1)

   def getLocalHardwareSupportInfo(self):
      """Get a tuple of:
         1) A dict of hardware support manager names that map to names and
            then versions of hardware support components that are installed
            on host.
         2) Name-version dict of all components that are listed as part of
            hardware support packages.
         3) A set of all manifest remove component names.
      """
      hspInfo = dict()
      hspComps = dict()
      hspRmCompNames = set()

      manifests = self.hostImageProfile.manifests
      if not manifests:
         # Avoid below conversion.
         return hspInfo, hspComps, hspRmCompNames

      # XXX: image profile has bulletins, not components.
      hostComps = ComponentCollection(self.hostImageProfile.bulletins)

      for manifest in manifests.values():
         hspCompInfo = dict()
         for compName, compVer in manifest.components.items():
            if hostComps.HasComponent(compName, compVer):
               comp = hostComps.GetComponent(compName, compVer)
               hspCompInfo[compName] = comp.compVersionStr
         hsi = manifest.hardwareSupportInfo
         hspInfo[hsi.manager.name] = hspCompInfo
         hspComps.update(manifest.components)
         hspRmCompNames.update(set(manifest.removedComponents))

      return hspInfo, hspComps, hspRmCompNames

   def getLocalSolutionInfo(self):
      """Get a tuple of:
         1) A dict of SolutionComponentDetails for local solution components,
            indexed by solution name and then component name.
         2) Names of components that are installed as part of solutions.
      """
      solInfo = dict()
      solCompNames = list()

      solutions = self.hostImageProfile.solutions
      if not solutions:
         return solInfo, solCompNames

      # XXX: image profile has bulletins.
      comps = ComponentCollection(self.hostImageProfile.bulletins)

      for solution in solutions.values():
         info = getSolutionInfo(solution, comps)
         solInfo[solution.nameSpec.name] = info
         solCompNames += [scd.component for scd in info.components]

      return solInfo, solCompNames

   def scanLocalComponents(self, biComponents, addOnComponents,
                           addOnRemovedCompNames, hspComps,
                           hspRemovedCompNames, solutionCompNames):
      """Compute the local installed compoments against those in base image,
         addon, manifests and solution.
         Specifically record components that are:
         1) Remove/downgraded in base image and addon.
         2) Given by user to override or add to base image, addon and manifests.
         3) Provided by a solution.
         4) Provided by a hardware support package.
      """
      ADD, UPGRADE, DOWNGRADE = 'add', 'upgrade', 'downgrade'

      def _addCompInSpec(compName, comp, spec, subject, hostVer, subjectVer):
         """Triage a component to one of add, upgrade and downgrade categories
            according to host's and the spec piece's component versions.
            An addition in the spec dict means the spec piece (e.g. addon)
            adds the component, or upgrades/downgrades the component of another
            image piece (subject), e.g. base image.
         """
         if hostVer > subjectVer:
            spec[UPGRADE][subject][compName] = comp
         elif hostVer < subjectVer:
            spec[DOWNGRADE][subject][name] = comp
         else:
            # Even if multiple pieces claim the same version, the component
            # will be treated as "add" in all of them. This makes sure upgrade
            # and downgrade components are calculated correctly.
            spec[ADD][name] = comp

      addOnRemovedCompNames = addOnRemovedCompNames or []
      hspRemovedCompNames = hspRemovedCompNames or set()
      # All component names appear in the addon, base image and manifests.

      biAddonHspCompNames = set(biComponents.keys())
      if addOnRemovedCompNames:
         biAddonHspCompNames -= set(addOnRemovedCompNames)
      if addOnComponents:
         biAddonHspCompNames |= set(addOnComponents.keys())
      if hspRemovedCompNames:
         biAddonHspCompNames -= hspRemovedCompNames
      if hspComps:
         biAddonHspCompNames |= set(hspComps.keys())

      # Base image components.
      baseImageCompSpec = dict()
      # A breakdown of addon components regarding base image components.
      addonCompSpec = {
         ADD: dict(),
         UPGRADE: {
            BASE_IMG: dict(),
         },
         DOWNGRADE: {
            BASE_IMG: dict(),
         },
      }
      # A breakdown of hardware support components' relationship related to
      # base image and addon.
      hspCompSpec = {
         ADD: dict(),
         UPGRADE: {
            BASE_IMG: dict(),
            ADD_ON: dict()
         },
         DOWNGRADE: {
            BASE_IMG: dict(),
            ADD_ON: dict(),
         },
      }
      # A breakdown of user components regarding manifest components.
      userCompSpec = {
         ADD: dict(),
         UPGRADE: {
            BASE_IMG: dict(),
            ADD_ON: dict(),
            HARDWARE_SUPPORT: dict(),
         },
         DOWNGRADE: {
            BASE_IMG: dict(),
            ADD_ON: dict(),
            HARDWARE_SUPPORT: dict(),
         },
      }

      installedComps = self.hostImageProfile.ListComponentSummaries()
      installedCompNames = set()
      for comp in installedComps:
         # Loop to figure out upgrade/downgrade relations.
         name = comp['component']
         installedCompNames.add(name)

         if name in solutionCompNames:
            # Solution component.
            continue

         if name not in biAddonHspCompNames:
            # Component introduced by the user, could be a new component,
            # or one that is removed by addon but re-added by user.
            userCompSpec[ADD][name] = comp
         else:
            # Find the provider of the component and if there is any
            # upgrade/downgrade took place.
            hostVersion = VibVersion.fromstring(comp[VERSION])
            biVersion = (VibVersion.fromstring(biComponents[name])
                         if name in biComponents else None)
            addonVersion = (VibVersion.fromstring(addOnComponents[name])
                            if addOnComponents and name in addOnComponents
                            else None)
            hspVersion = (VibVersion.fromstring(hspComps[name]) if hspComps
                          and name in hspComps else None)

            if isNotNone(biVersion):
               # Base image originally has the component.
               if biVersion == hostVersion:
                  # No override.
                  baseImageCompSpec[name] = comp
               elif isNotNone(addonVersion) and addonVersion == hostVersion:
                  # Addon override base image, it should be upgrade only, but
                  # we will check all cases nevertheless.
                  _addCompInSpec(name, comp, addonCompSpec, BASE_IMG,
                                 hostVersion, biVersion)
               elif isNotNone(hspVersion) and hspVersion == hostVersion:
                  # HSP overrides base image, it should be upgrade only, but
                  # we will check all cases just like addon.
                  _addCompInSpec(name, comp, hspCompSpec, BASE_IMG,
                                 hostVersion, biVersion)
               else:
                  # User component override base image, "add" was already
                  # handled, so here should only be upgrade/downgrade.
                  _addCompInSpec(name, comp, userCompSpec, BASE_IMG,
                                 hostVersion, biVersion)
            elif isNotNone(addonVersion):
               # Addon originally has the component.
               if addonVersion == hostVersion:
                  # Addon adds the component.
                  addonCompSpec[ADD][name] = comp
               elif isNotNone(hspVersion) and hspVersion == hostVersion:
                  # HSP overrides addon, it should be upgrade only, but
                  # we will check all cases just like addon.
                  _addCompInSpec(name, comp, hspCompSpec, ADD_ON,
                                 hostVersion, addonVersion)
               else:
                  # User component override addon, "add" was already
                  # handled, so here should only be upgrade/downgrade.
                  _addCompInSpec(name, comp, userCompSpec, ADD_ON,
                                 hostVersion, addonVersion)
            else:
               # HSP originally has the component.
               if hspVersion == hostVersion:
                  # Manifest adds the component.
                  hspCompSpec[ADD][name] = comp
               else:
                  # User component upgrades/downgrades HSP.
                  _addCompInSpec(name, comp, userCompSpec, HARDWARE_SUPPORT,
                                 hostVersion, hspVersion)

      # Sets for the components of interest.
      removedBIComps = ((set(biComponents.keys()) - installedCompNames) -
                         set(addOnRemovedCompNames) - set(hspRemovedCompNames))
      downgradedBIComps = (set(addonCompSpec[DOWNGRADE][BASE_IMG].keys() |
                           set(hspCompSpec[DOWNGRADE][BASE_IMG].keys()) |
                            set(userCompSpec[DOWNGRADE][BASE_IMG].keys())) -
                            set(addOnRemovedCompNames) -
                            set(hspRemovedCompNames))

      removedAddonComps, downgradedAddonComps = set(), set()
      if addOnComponents:
         removedAddonComps = (set(addOnComponents.keys()) -
                              installedCompNames -
                              set(hspRemovedCompNames))
         downgradedAddonComps = (set(hspCompSpec[DOWNGRADE][ADD_ON].keys()) |
                                 set(userCompSpec[DOWNGRADE][ADD_ON].keys()) -
                                 set(hspRemovedCompNames))
      # All addon components
      allAddonComps = dict()
      allAddonComps.update(addonCompSpec[ADD])
      allAddonComps.update(addonCompSpec[UPGRADE][BASE_IMG])
      allAddonComps.update(addonCompSpec[DOWNGRADE][BASE_IMG])

      # All user components.
      allUserComps = dict()
      allUserComps.update(userCompSpec[ADD])
      allUserComps.update(userCompSpec[UPGRADE][HARDWARE_SUPPORT])
      allUserComps.update(userCompSpec[UPGRADE][ADD_ON])
      allUserComps.update(userCompSpec[UPGRADE][BASE_IMG])
      allUserComps.update(userCompSpec[DOWNGRADE][HARDWARE_SUPPORT])
      allUserComps.update(userCompSpec[DOWNGRADE][ADD_ON])
      allUserComps.update(userCompSpec[DOWNGRADE][BASE_IMG])

      compInfo = dict()

      # List of info dictionary.
      # TODO: refactor the usage to also use dictionary and not
      # convert back-and-forth between dictionary and list.
      compInfo[USER_COMPS_KEY] = list(allUserComps.values())

      # Name to info dictionaries.
      compInfo[BASEIMAGE_COMPS_KEY] = baseImageCompSpec
      compInfo[ADDON_COMPS_KEY] = allAddonComps
      # Lists of names.
      compInfo[REMOVED_DG_BI_COMP_KEY] = removedBIComps | downgradedBIComps
      compInfo[REMOVED_DG_ADDON_COMP_KEY] = (removedAddonComps |
                                             downgradedAddonComps)
      return compInfo

   def getHostOrphanVibs(self):
      """
      Get IDs of orphan VIBs on the host, i.e. VIBs on the host that are not a
      part of installed components.
      """
      compVibs = set()
      profile = self.hostImageProfile
      for bulletin in profile.bulletins.values():
         compVibs = compVibs.union(bulletin.vibids)
      return list(profile.vibIDs - compVibs)

   def getImageProfileScanSpec(self):
      """ For personality manager. Converts the host Image Profile into
      a Software scan Specification.
      Core Logic:
      1. Get the BaseImage info from host
      2. Get the Addon info from host
      3. Get all Hardware Support components from host
      4. Scan for local component changes
      5. Get the orphan vibs

      Sample Spec with BaseImage/Addon/Solution info objects exploded:

      {"base_image":{"version": "6.8.7-1213313",
                     "display_name": "xyz",
                     "display_version": "xyz",
                     "release_date":"abc"},
       "add_on": {"version": "6.8.7-1213313",
                  "display_version":"xyz",
                  "name":"abc",
                  "display_name": "xyz",
                  "vendor":"vmw"},
       "base_image_components": {"test":{"component": "test",
                                         "version": "6.8.7-1213313",
                                         "display_name": "test",
                                         "display_version": "xyz",
                                         "vendor": "vmw"}},
       "addon_components": {"test":{"component": "test",
                                    "version": "6.8.7-1213313",
                                    "display_name": "test",
                                    "display_version": "xyz",
                                    "vendor": "vmw"}},
       "hardware_support": {
          "hardwareSupportManagerName": {
             "installedCompName": "1.0-1"
          }
       },
       "user_components": {"test":{"component": "test",
                                   "version": "6.8.7-1213313",
                                   "display_name": "test",
                                   "display_version": "xyz",
                                   "vendor": "vmw"}},
       "removed_or_downgraded_bi_components": {"test1"},
       "removed_or_downgraded_add_on_components": {"test2"},
       "orphan_vibs": ["Vendor_bootbank_vib1_1.0-1"],
       "solutions": [
         {
            "name": "solution-1",
            "version": "1.0-1",
            "display_name": "solution 1",
            "display_version": "1.0 release 1",
            "components": [
               {
                  "component": "component-1",
                  "version": "1.0-1",
                  "display_name": "component 1",
                  "display_version": "1.0 release 1",
                  "vendor": "VMware"
              }
            ]
         }
         ]
      }
      """
      scanSpec = dict()

      # Base Image info
      currentBI = self.hostImageProfile.baseimage
      if currentBI:
         # Base image object in esximage does not have UI name string,
         # initializing it with 'ESXi'
         uiName = BASEIMAGE_UI_NAME
         baseImageInfo = getBaseImageInfo(uiName,
                                  currentBI.versionSpec.version.versionstring,
                                  currentBI.versionSpec.uiString,
                                  currentBI.releaseDate)
         baseImageComponents = currentBI.components
      else:
         # Base image info is required, use empty strings and current time.
         baseImageInfo = getBaseImageInfo('', '', '', datetime.utcnow())
         baseImageComponents = dict()
      scanSpec[BASE_IMG] = baseImageInfo

      # Addon Info
      addOnInfo = None
      addOnComponents, addOnRemovedCompNames = None, None
      addon = self.hostImageProfile.addon
      if addon:
         addOnInfo = getAddOnInfo(addon.nameSpec.name,
                                  addon.nameSpec.uiString,
                                  addon.versionSpec.version.versionstring,
                                  addon.versionSpec.uiString,
                                  addon.vendor)
         addOnComponents = addon.components
         addOnRemovedCompNames = addon.removedComponents
      scanSpec[ADD_ON] = addOnInfo

      # Manifests Info
      hspDict, allHspCompDict, allHspRmCompNames = \
                                             self.getLocalHardwareSupportInfo()
      scanSpec[HARDWARE_SUPPORT] = hspDict

      # Solution info.
      solDict, solCompNames = self.getLocalSolutionInfo()
      scanSpec[SOLUTIONS] = solDict

      # Compute components info
      compInfo = self.scanLocalComponents(baseImageComponents, addOnComponents,
                                          addOnRemovedCompNames, allHspCompDict,
                                          allHspRmCompNames, solCompNames)
      scanSpec.update(compInfo)

      # Compute orphan vibs
      scanSpec[ORPHAN_VIBS] = self.getHostOrphanVibs()
      return scanSpec

   def _processPrecheckResult(self, result):
      """Form notification messages for a precheck error/warning result.
         Input is a precheck Result object, the current error notifications,
         and the current warning notifications.
         Side effect: based on the type, an error/warning notification will
         be appended to the overall notifications.
      """
      def _formAndAddMsg(result, msgId, found, expected):
         # We need to tell which args are needed. For this purpose, we formulate
         # all messages to have formatter {1} for found and {2} for expected.
         msg = NOTIFICATION_MSG[msgId]
         msgArgs = []
         if msg.find('{1}') != -1:
            msgArgs.append(','.join(str(x) for x in found))
         if msg.find('{2}') != -1:
            msgArgs.append(','.join(str(x) for x in expected))
         notification = getNotification(msgId,
                                        msgId,
                                        msgArgs=msgArgs)
         if result.code == result.ERROR:
            self.overallNotifications.errors.append(notification)
         elif result.code == result.WARNING:
            self.overallNotifications.warnings.append(notification)

      msgId = PRECHECK_NOTIFICATION_ID[result.name]
      # Format message with found and expected. Not all string require
      # both in the string, but format() will not complain about it.
      if msgId == UNSUPPORTED_VENDOR_MODEL_ID:
         # Hardware mismatch can bring multiple errors, each in tuple
         # (vendor/model, image-value, host-value). Convert them to
         # multiple found != expected precheck errors.
         for match, image, host in result.found:
            realMsgId = msgId % match.capitalize()
            _formAndAddMsg(result, realMsgId, [host], [image])
      else:
         # Otherwise use found and expected to format one message.
         _formAndAddMsg(result, msgId, result.found, result.expected)

   def checkHardwareCompatibility(self):
      """Perform hardware compatibility precheck through weasel's
         upgrade_precheck.py.
         This method should be called only when base image is incompliant,
         otherwise we will be re-running checks that have already been
         done when the host was imaged.
         Returns: A True/False flag indicating if the system is compatible.
      """
      # Weasel is not in python path, we need to import it with relative
      # path in this patcher.
      # This script is in:
      # lib64/python<ver>/site-packages/vmware/esximage/ImageManager/
      # Weasel is in:
      # usr/lib/vmware/weasel/
      modulePath = os.path.dirname(os.path.abspath(__file__))
      patcherRoot = os.path.normpath(os.path.join(modulePath, '..', '..', '..',
                                                  '..', '..', '..'))
      vmwarePath = os.path.join(patcherRoot, 'usr', 'lib', 'vmware')
      if vmwarePath not in sys.path:
         sys.path.insert(0, vmwarePath)

      # Precheck imports from 'esximage' rather than 'vmware.esximage',
      # for most cases we are okay since patch the patcher sets it up
      # when the patcher's version has been bumped up. But for certain
      # base image incompliant cases, such as only because of a component
      # in it is overridden by an user component, we do not have a new
      # patcher and need to make sure 'vmware' path exists.
      vmwarePath = os.path.normpath(os.path.join(modulePath, '..', '..'))
      if vmwarePath not in sys.path:
         sys.path.insert(0, vmwarePath)

      from weasel.util import upgrade_precheck as precheck
      errors, warnings = precheck.imageManagerAction(self.hostImageProfile,
                                                     self.desiredImageProfile)

      # Warnings do not make the host incompatible, but they are sent up in
      # overall notifications.
      for result in errors + warnings:
         self._processPrecheckResult(result)
      return len(errors) == 0

   def computeBaseImageCompliance(self):
      """
      Compute base image compliance data. In this function the installed
      baseimage version is compared with the desired base image version
      and the compliance info based on the check will be returned. Compliance
      status will be decided based on the versions and if the status is
      compliant and if some of the base image components are removed by the
      user from the host then the status will be returned as NON-COMPLIANT
      with a warning
      :return: Base Image Compliance info
      """
      infoMsgs, errMsgs = [], []

      # Comparing base image version
      currentBIInfo = self.currentSoftwareScanSpec[BASE_IMG]
      currentVersion = currentBIInfo.version
      desiredBIObj = self.desiredImageProfile.baseimage
      desiredVersion = desiredBIObj.versionSpec.version.versionstring
      if currentVersion:
         status, errMsg = getVersionCompliance(desiredVersion,
                                               currentVersion,
                                               "ESXi",
                                               BASE_IMAGE)
         if errMsg:
            errMsgs.append(errMsg)
      else:
         status = NON_COMPLIANT

      if status == COMPLIANT:
         # Check if there are any missing base image components when
         # version is in compliant.
         baseImageRemovedComponents = (
            self.currentSoftwareScanSpec[REMOVED_DG_BI_COMP_KEY])

         if baseImageRemovedComponents:
            # Changing the status as NON-COMPLIANT.
            status = NON_COMPLIANT
            msgArgs = [", ".join(baseImageRemovedComponents)]
            infoMsg = getNotification(BASEIMAGE_COMPONENT_REMOVED_ID,
                                      BASEIMAGE_COMPONENT_REMOVED_ID,
                                      msgArgs=msgArgs)
            infoMsgs.append(infoMsg)

      # Base image object in esximage does not have UI name string,
      # initializing it with 'ESXi'
      uiName = BASEIMAGE_UI_NAME
      targetBIInfo = getBaseImageInfo(uiName,
                                      desiredVersion,
                                      desiredBIObj.versionSpec.uiString,
                                      releaseDate=desiredBIObj.releaseDate)

      notifications = Notifications(info=getOptionalVal(infoMsgs),
                                    errors=getOptionalVal(errMsgs))
      baseImageCompliance = BaseImageCompliance(status=ComplianceStatus(status),
                                                current=currentBIInfo,
                                                target=targetBIInfo,
                                                notifications=notifications)
      return baseImageCompliance

   def computeAddOnCompliance(self):
      """
      Compute addon compliant status, return a result that is similar to
      baseimage compliance.
      In addition, if there's no addon installed and no addons specified in
      desired state then the status will be returrned as COMPLIANT
      :return: addon Compliance info
      """
      errMsgs, infoMsgs = [], []
      targetAddOnObj = self.desiredImageProfile.addon
      currentAddOnInfo = self.currentSoftwareScanSpec[ADD_ON]

      # Default compliant result and None target addon.
      status = COMPLIANT
      targetAddOnInfo = None

      if targetAddOnObj:
         # Desired state has addon.
         targetAddOnName = targetAddOnObj.nameSpec.name
         targetAddOnVersion = targetAddOnObj.versionSpec.version.versionstring
         targetAddOnInfo = getAddOnInfo(targetAddOnName,
                                        targetAddOnObj.nameSpec.uiString,
                                        targetAddOnVersion,
                                        targetAddOnObj.versionSpec.uiString,
                                        targetAddOnObj.vendor)

         if currentAddOnInfo:
            # Both installed and desired state have addon.
            currentAddOnName = currentAddOnInfo.name
            currentAddOnVersion = currentAddOnInfo.version

            if currentAddOnName != targetAddOnName:
               # Installed addon and desired addon are different.
               status = NON_COMPLIANT
               msgArgs = [currentAddOnName, currentAddOnVersion]
               infoMsg = getNotification(ADDON_REMOVAL_ID,
                                         ADDON_REMOVAL_ID,
                                         msgArgs=msgArgs)
               infoMsgs.append(infoMsg)
            else:
               # Compare the version of installer/desired addon.
               status, errMsg = getVersionCompliance(targetAddOnVersion,
                                                     currentAddOnVersion,
                                                     targetAddOnName,
                                                     ADDON)

               if errMsg:
                  errMsgs.append(errMsg)

               if status == COMPLIANT:
                  # Check if there are any missing addon components when
                  # version is in compliant.
                  addonRemovedComponents = (
                     self.currentSoftwareScanSpec[REMOVED_DG_ADDON_COMP_KEY])
                  if addonRemovedComponents:
                     # Changing the status as NON-COMPLIANT.
                     status = NON_COMPLIANT
                     msgArgs = [", ".join(addonRemovedComponents)]
                     infoMsg = getNotification(ADDON_COMPONENT_REMOVED_ID,
                                               ADDON_COMPONENT_REMOVED_ID,
                                               msgArgs=msgArgs)
                     infoMsgs.append(infoMsg)
         else:
            # There is an addon to install.
            status = NON_COMPLIANT
      elif currentAddOnInfo:
         # When addon is installed and is not present in the desired state.
         # Start with a regular addon removal non-compliant status.
         status = NON_COMPLIANT
         msgArgs = [currentAddOnInfo.name, currentAddOnInfo.version]
         infoMsg = getNotification(ADDON_REMOVAL_ID,
                                   ADDON_REMOVAL_ID,
                                   msgArgs=msgArgs)
         infoMsgs.append(infoMsg)

         # Check base image component overriden by the old addon is not
         # downgrading. User component downgrading an old addon component is
         # checked in component compliance, and solution component would not
         # overlap with base image.
         currentAddOnObj = self.hostImageProfile.addon
         targetBaseImageObj = self.desiredImageProfile.baseimage
         installedAddonComps = \
                     set(self.currentSoftwareScanSpec[ADDON_COMPS_KEY].keys())
         targetCompsMap = {b.compNameStr: b.compVersionStr
                           for b in self.desiredImageProfile.bulletins.values()}
         targetBiComps = targetBaseImageObj.components
         for compName, verStr in currentAddOnObj.components.items():
            if (compName in installedAddonComps and
                compName in targetBiComps and
                compName in targetCompsMap and
                targetCompsMap[compName] == targetBiComps[compName]):
               # The exact addon component is present on host and the new base
               # image's version is in effective components of the new image.
               compStatus, errMsg = getVersionCompliance(
                                       targetBaseImageObj.components[compName],
                                       verStr,
                                       compName,
                                       OLD_ADDON_COMP)
               if compStatus == INCOMPATIBLE:
                  # Downgrade found, addon compliance will be incompatible.
                  status = INCOMPATIBLE
                  errMsgs.append(errMsg)

      notifications = Notifications(info=getOptionalVal(infoMsgs),
                                    errors=getOptionalVal(errMsgs))
      addOnCompliance = AddOnCompliance(status=ComplianceStatus(status),
                                        current=currentAddOnInfo,
                                        target=targetAddOnInfo,
                                        notifications=notifications)
      return addOnCompliance

   def computeHardwareSupportCompliance(self):
      """Compute hardware support compliance status, return a map of
         HardwareSupportPackageCompliance objects indexed by hardware
         support manager names.
      """
      def _getManifestCompsCompliance(manifest, checkIncompatible=True):
         """Checks compliance of components in a manifest versus the currently
            installed manifest components.
            Returns a compliance status (one of compiant, non-compliant and
            by default incompatible) and notifications.
            When checkIncompatible is set, treat component downgrade as
            incompatible, this is applicable for an incoming manifest.
         """
         # Comp groups of the manifest related to the host.
         dgComps, upComps, addComps = set(), set(), set()
         hsi = manifest.hardwareSupportInfo
         hsp, hspVer = hsi.package.name, hsi.package.version
         installedHsmComps = \
            self.currentSoftwareScanSpec[HARDWARE_SUPPORT][hsi.manager.name]

         for comp, version in manifest.components.items():
            if comp in installedHsmComps:
               status, _ = getVersionCompliance(version,
                                                installedHsmComps[comp],
                                                comp,
                                                COMPONENT)
               # Check for cases that manifest's comp is a downgrade or
               # upgrade of the one on the host.
               if status == INCOMPATIBLE:
                  dgComps.add(comp)
               elif status == NON_COMPLIANT:
                  upComps.add(comp)
            else:
               addComps.add(comp)

         if dgComps and checkIncompatible:
            # Installing this manifest will downgrade component(s) of another
            # manifest.
            status = INCOMPATIBLE
            errMsg = getNotification(HSP_COMP_HSP_DOWNGRADE_ID,
                                     HSP_COMP_HSP_DOWNGRADE_ID,
                                     msgArgs=[', '.join(dgComps), hsp, hspVer])
            notifications = Notifications(errors=[errMsg])
         elif upComps or addComps:
            status = NON_COMPLIANT
            infoMsg = getNotification(HSP_COMPONENT_REMOVED_ID,
                                      HSP_COMPONENT_REMOVED_ID,
                                      msgArgs=[', '.join(upComps | addComps)])
            notifications = Notifications(info=[infoMsg])
         else:
            status = COMPLIANT
            notifications = None
         return status, notifications

      def _getRemovedManifestCompliance(manifest):
         """Checks downgrade status of HSP components being removed.
            Returns a compliance status (compliant or incompatible) and
            notifications.
         """
         hsp, hspVer = (manifest.hardwareSupportInfo.package.name,
                        manifest.hardwareSupportInfo.package.version)

         newAddon = self.desiredImageProfile.addon
         newBaseImage = self.desiredImageProfile.baseimage
         newCompsMap = {b.compNameStr: b.compVersionStr
                        for b in self.desiredImageProfile.bulletins.values()}
         addonComps = ({c: v for c, v in newAddon.components.items()
                        if (c, v) in newCompsMap.items()}
                       if newAddon else dict())
         baseImageComps = {c: v for c, v in newBaseImage.components.items()
                           if (c, v) in newCompsMap.items()}

         addonDgComps, biDgComps = set(), set()
         for comp, version in manifest.components.items():
            if comp in addonComps:
               status, _ = getVersionCompliance(addonComps[comp],
                                                version,
                                                comp,
                                                COMPONENT)
               if status == INCOMPATIBLE:
                  addonDgComps.add(comp)
            elif comp in baseImageComps:
               status, _ = getVersionCompliance(version,
                                                baseImageComps[comp],
                                                comp,
                                                COMPONENT)
               if status == INCOMPATIBLE:
                  biDgComps.add(comp)

         status = INCOMPATIBLE if addonDgComps or biDgComps else COMPLIANT
         errMsgs = []
         if addonDgComps:
            errMsgs.append(getNotification(RM_HSP_COMP_ADDON_DOWNGRADE_ID,
                                           RM_HSP_COMP_ADDON_DOWNGRADE_ID,
                                           msgArgs=[', '.join(addonDgComps),
                                                    hsp, hspVer]))
         if biDgComps:
            errMsgs.append(getNotification(RM_HSP_COMP_BASEIMAGE_DOWNGRADE_ID,
                                           RM_HSP_COMP_BASEIMAGE_DOWNGRADE_ID,
                                           msgArgs=[', '.join(biDgComps),
                                                    hsp, hspVer]))
         notifications = Notifications(errors=errMsgs) if errMsgs else None

         return status, notifications

      hspCompliance = dict()
      targetManifests = self.desiredImageProfile.manifests
      hostManifests = self.hostImageProfile.manifests

      targetManifestMap = {m.hardwareSupportInfo.manager.name: m
                           for m in targetManifests.values()}
      hostManifestMap = {m.hardwareSupportInfo.manager.name: m
                         for m in hostManifests.values()}
      targetHsms = set(targetManifestMap.keys())
      hostHsms = set(hostManifestMap.keys())

      for hsm in targetHsms - hostHsms:
         # New HSMs
         hspCompliance[hsm] = getHardwareSupportCompliance(
                                                   NON_COMPLIANT,
                                                   None,
                                                   targetManifestMap[hsm],
                                                   None)

      for hsm in hostHsms - targetHsms:
         # HSMs pending removal.
         status, notifications = \
                           _getRemovedManifestCompliance(hostManifestMap[hsm])
         if status == INCOMPATIBLE:
            # Addon/baseimage of the desired image contains downgrade of
            # currently installed components in HSP.
            hspCompliance[hsm] = getHardwareSupportCompliance(
                                                         INCOMPATIBLE,
                                                         hostManifestMap[hsm],
                                                         None,
                                                         notifications)
         else:
            hsp, hspVer = \
               (hostManifestMap[hsm].hardwareSupportInfo.package.name,
                hostManifestMap[hsm].hardwareSupportInfo.package.version)
            infoMsg = getNotification(HSP_REMOVAL_ID,
                                      HSP_REMOVAL_ID,
                                      msgArgs=[hsp, hspVer])
            hspCompliance[hsm] = getHardwareSupportCompliance(
                                                NON_COMPLIANT,
                                                hostManifestMap[hsm],
                                                None,
                                                Notifications(info=[infoMsg]))

      for hsm in targetHsms & hostHsms:
         # Installed or partially installed HSMs.
         hostManifest, targetManifest = \
                                    hostManifestMap[hsm], targetManifestMap[hsm]
         hostHsp, targetHsp = (hostManifest.hardwareSupportInfo.package,
                               targetManifest.hardwareSupportInfo.package)
         if hostHsp.name != targetHsp.name:
            # Different HSP, check no component downgrade from the current HSP
            # to the target one.
            status, notifications = _getManifestCompsCompliance(targetManifest)
            if status == INCOMPATIBLE:
               # Downgrade of comps means incompatible.
               hspCompliance[hsm] = getHardwareSupportCompliance(
                                                         INCOMPATIBLE,
                                                         hostManifest,
                                                         targetManifest,
                                                         notifications)
            else:
               # Simply non-compliant for the removal.
               hspCompliance[hsm] = getHardwareSupportCompliance(
                                                         NON_COMPLIANT,
                                                         hostManifest,
                                                         targetManifest,
                                                         None)
         else:
            hspStatus, errMsg = getVersionCompliance(targetHsp.version,
                                                     hostHsp.version,
                                                     hostHsp.name,
                                                     HARDWARE_SUPPORT)
            if hspStatus != COMPLIANT:
               # HPS version upgrade or downgrade.
               notifications = (Notifications(errors=[errMsg])
                                if errMsg else None)
               hspCompliance[hsm] = getHardwareSupportCompliance(
                                                hspStatus,
                                                hostManifest,
                                                targetManifest,
                                                notifications)
            else:
               # With the same HSM-HSP, we could still have different components
               # across manifests. We will only verify the current manifest on
               # host is fully installed (ignore incompatible component due to
               # user component overwrite).
               status, notifications = \
                           _getManifestCompsCompliance(hostManifest,
                                                       checkIncompatible=False)
               hspCompliance[hsm] = getHardwareSupportCompliance(
                                                status,
                                                hostManifest,
                                                targetManifest,
                                                notifications)
      return hspCompliance

   def computeSolutionCompliance(self):
      """Compute solution compliance and return a dict of SolutionCompliance
         objects indexed by solution names.
      """
      curSolutions = self.currentSoftwareScanSpec[SOLUTIONS]
      newSolutions = {s.nameSpec.name: s
                      for s in self.desiredImageProfile.solutions.values()}
      # XXX: image profile has bulletins.
      allCurComps = ComponentCollection(self.hostImageProfile.bulletins)
      allNewComps = ComponentCollection(self.desiredImageProfile.bulletins)

      # Contains name, version tuples of solutions enabled/disabled.
      # This is for generating overall solution notifications.
      enableSols, disableSols = list(), list()

      curSols, newSols = set(curSolutions.keys()), set(newSolutions.keys())
      removes = curSols - newSols
      adds = newSols - curSols
      common = curSols & newSols

      solCompliance = dict()

      for name in removes:
         curInfo = curSolutions[name]
         disableSols.append((curInfo.details.display_name,
                             curInfo.details.display_version))
         solCompliance[name] = SolutionCompliance(
                                       status=ComplianceStatus(NON_COMPLIANT),
                                       current=curInfo,
                                       notifications=Notifications())

      for name in adds:
         newInfo = getSolutionInfo(newSolutions[name], allNewComps)
         enableSols.append((newInfo.details.display_name,
                            newInfo.details.display_version))
         solCompliance[name] = SolutionCompliance(
                                       status=ComplianceStatus(NON_COMPLIANT),
                                       target=newInfo,
                                       notifications=Notifications())

      for name in common:
         curInfo = curSolutions[name]
         # SolutionInfo class stores version in string.
         newInfo = getSolutionInfo(newSolutions[name], allNewComps)

         # Compare solution version first.
         status, errMsg = getVersionCompliance(newInfo.version,
                                               curInfo.version,
                                               name,
                                               SOLUTION)
         if status != COMPLIANT:
            # Non-compliant or incompatible.

            if errMsg:
               # Incompatible takes precedent.
               notifications = Notifications(errors=[errMsg])
            else:
               # Non-compliant by solution version, no per-solution
               # notification.
               disableSols.append((curInfo.details.display_name,
                                   curInfo.details.display_version))
               enableSols.append((newInfo.details.display_name,
                                  newInfo.details.display_version))
               notifications = Notifications()

            solCompliance[name] = SolutionCompliance(
                                                status=ComplianceStatus(status),
                                                current=curInfo,
                                                target=newInfo,
                                                notifications=notifications)
            continue

         # Compare actual components installed.
         curComps = {c.component: allCurComps.GetComponent(c.component)
                     for c in curInfo.components}
         newComps = {c.component: allNewComps.GetComponent(c.component)
                     for c in newInfo.components}
         rmCompArgs, downCompArgs = [], []
         compUpdated = False
         compAdded = bool(set(newComps.keys()) - set(curComps.keys()))
         for compName, comp in curComps.items():
            if compName not in newComps:
               # Previous solution component removed.
               rmCompArgs.append('%s(%s)'
                                 % (compName, comp.compVersionStr))
            elif comp.compVersion > newComps[compName].compVersion:
               # Previous solution component downgraded, should not normally
               # happen.
               downCompArgs.append('%s(%s)'
                                   % (compName, comp.compVersionStr))
            elif comp.compVersion < newComps[compName].compVersion:
               # Previous solution component updated.
               compUpdated = True

         # Sort out solution compliance and notifications:
         #   Component downgraded -> incompatible + per-solution notification
         #                           about the downgrade
         #   Component removed -> non-compliant + per-solution notification
         #                        about the removal + overall notifications
         #   Component updated/added -> non-compliant + overall notifications
         status = NON_COMPLIANT if compUpdated or compAdded else COMPLIANT
         warnMsgs, errMsgs = [], []
         if rmCompArgs:
            status = NON_COMPLIANT
            warnMsgs.append(
                  getNotification(SOLUTIONCOMPONENT_REMOVAL_ID,
                                  SOLUTIONCOMPONENT_REMOVAL_ID,
                                  msgArgs=[','.join(rmCompArgs), name]))
         if downCompArgs:
            # Do this late to get the correct status.
            status = INCOMPATIBLE
            errMsgs.append(
                  getNotification(SOLUTIONCOMPONENT_DOWNGRADE_ID,
                                  SOLUTIONCOMPONENT_DOWNGRADE_ID,
                                  msgArgs=[','.join(downCompArgs), name]))

         if status == NON_COMPLIANT:
            # Same solution, but missing/downgraded components found on host,
            # this means only an enable message is sufficient.
            enableSols.append((newInfo.details.display_name,
                               newInfo.details.display_version))

         notifications = Notifications(warnings=getOptionalVal(warnMsgs),
                                       errors=getOptionalVal(errMsgs))
         solCompliance[name] = SolutionCompliance(
                                          status=ComplianceStatus(status),
                                          current=curInfo,
                                          target=newInfo,
                                          notifications=notifications)

      if disableSols:
         msgArgs = [', '.join(['%s %s' % (n, v) for n, v in disableSols])]
         infoMsg = getNotification(SOLUTION_DISABLE_ID,
                                   SOLUTION_DISABLE_ID,
                                   msgArgs=msgArgs)
         self.overallNotifications.info.append(infoMsg)
      if enableSols:
         msgArgs = [', '.join(['%s %s' % (n, v) for n, v in enableSols])]
         infoMsg = getNotification(SOLUTION_ENABLE_ID,
                                   SOLUTION_ENABLE_ID,
                                   msgArgs=msgArgs)
         self.overallNotifications.info.append(infoMsg)

      return solCompliance

   def computeImageImpact(self):
      """Compute image impact and generate a notification for the impact.
         In case the host is pending reboot from a prior software change,
         another info notification will be generated to reflect it.
      """
      # Reboot/MMode impact of the remediation.
      impact, rebootPending = getImageProfileImpact(self.hostImage,
                                                    self.desiredImageProfile)

      if impact != IMPACT_NONE:
         impactId = (MAINTMODE_IMPACT_ID if impact == IMPACT_MMODE else
                     REBOOT_IMPACT_ID)
         msgDict = getNotification(impactId, impactId)
         self.overallNotifications.warnings.append(msgDict)
      if rebootPending:
         infoMsg = getNotification(PENDING_REBOOT_ID, PENDING_REBOOT_ID)
         self.overallNotifications.info.append(infoMsg)

      return impact

   def computeComponentsCompliance(self):
      """Compute user component compliance data by looking at user overriden
         components in the current and the desired image. This excludes
         components that are a part of solutions.
         Returns a dictionary of ComponentComplianceInfo indexed by component
         names.
      """
      # Local/target HSP components flattened to a set.
      localHspComps = set().union(*[set(d.keys()) for d in
                     self.currentSoftwareScanSpec[HARDWARE_SUPPORT].values()])
      targetHspComps = dict()
      for m in self.desiredImageProfile.manifests.values():
         targetHspComps.update(m.components)

      def _getHostCompSource(name):
         if name in self.currentSoftwareScanSpec[BASEIMAGE_COMPS_KEY]:
            return SOURCE_BASEIMAGE
         elif name in self.currentSoftwareScanSpec[ADDON_COMPS_KEY]:
            return SOURCE_ADDON
         elif name in localHspComps:
            return SOURCE_HSP
         else:
            return SOURCE_USER

      def _getDesiredCompSource(name, version):
         baseimage = self.desiredImageProfile.baseimage
         addon = self.desiredImageProfile.addon
         if (name in baseimage.components and
             baseimage.components[name] == version):
            return SOURCE_BASEIMAGE
         elif (addon and name in addon.components and
               addon.components[name] == version):
            return SOURCE_ADDON
         elif targetHspComps.get(name, None) == version:
            return SOURCE_HSP
         else:
            return SOURCE_USER

      def _getRemovalInfoMsg(name):
         infoMsg = getNotification(COMPONENT_REMOVAL_ID,
                                   COMPONENT_REMOVAL_ID,
                                   msgArgs=[name])
         return infoMsg

      def _getCompCompliance(status, current, target, currentSource,
                             targetSource, errMsg=None, infoMsg=None):
         infoMsgs = [infoMsg] if infoMsg else None
         errMsgs = [errMsg] if errMsg else None
         notifications = Notifications(info=infoMsgs,
                                       errors=errMsgs)
         curSrcObj = (ComponentSource(currentSource)
                          if isNotNone(currentSource) else None)
         targetSrcObj = (ComponentSource(targetSource)
                         if isNotNone(targetSource) else None)
         return ComponentCompliance(status=ComplianceStatus(status),
                                    current=current,
                                    target=target,
                                    current_source=curSrcObj,
                                    target_source=targetSrcObj,
                                    notifications=notifications)

      def _compSummaryToInfo(compSummaries):
         """Convert a list of component summary and the components' versions
            to a component info dict indexed by component names.
         """
         compDict = dict()
         for comp in compSummaries:
            compName = comp[COMPONENT]
            compVersion = comp[VERSION]
            # Component display name and version are not mandated, name and
            # version are used in case they are not provided.
            compInfo = getComponentInfo(comp[DISP_NAME] or compName,
                                        compVersion,
                                        comp[DISP_VERSION] or compVersion,
                                        comp[VENDOR])
            compDict[compName] = compInfo
         return compDict

      desiredUserComps = dict()
      if COMPONENTS in self.swSpec and self.swSpec[COMPONENTS]:
         desiredUserComps = self.swSpec[COMPONENTS]

      hostUserComps = _compSummaryToInfo(
                                 self.currentSoftwareScanSpec[USER_COMPS_KEY])

      compCompliance = dict()
      if not hostUserComps and not desiredUserComps:
         # No components to scan.
         return compCompliance

      hostComps = _compSummaryToInfo(
                           self.hostImageProfile.ListComponentSummaries())
      hostSolComps = set([c.component for s in
                          self.currentSoftwareScanSpec[SOLUTIONS].values()
                          for c in s.components])
      desiredComps = _compSummaryToInfo(
                           self.desiredImageProfile.ListComponentSummaries())
      desiredUserComps = {key: value for key, value in desiredComps.items()
                          if key in desiredUserComps}

      for name, comp in desiredUserComps.items():
         # Loop through desired components and find which installed components
         # will be removed and which will be updated.
         if name in hostComps:
            if name not in hostSolComps:
               # The user component present on host, check version compliance.
               current = hostComps[name]
               currentSource = _getHostCompSource(name)
               status, errMsg = getVersionCompliance(comp.version,
                                                     current.version,
                                                     name,
                                                     COMPONENT)
         else:
            # Component not present on host.
            current, currentSource = None, None
            status = NON_COMPLIANT
            errMsg = None

         compCompliance[name] = _getCompCompliance(status,
                                                   current,
                                                   comp,
                                                   currentSource,
                                                   SOURCE_USER,
                                                   errMsg=errMsg)

      for name, comp in hostUserComps.items():
         # Loop through installed user components and find any components that
         # will be removed or downgraded (by non-user components).
         if name in hostSolComps:
            continue

         if name not in desiredComps:
            # The component does not appear in the desired component list
            # means it is removed.
            infoMsg = _getRemovalInfoMsg(name)
            compCompliance[name] = _getCompCompliance(NON_COMPLIANT,
                                                      hostComps[name],
                                                      None,
                                                      SOURCE_USER,
                                                      None,
                                                      infoMsg=infoMsg)
         elif name in desiredComps and not name in desiredUserComps:
            # The component merges into base image, addon, HSP or solution.
            target = desiredComps[name]
            targetSource = _getDesiredCompSource(name, target.version)
            status, errMsg = getVersionCompliance(target.version,
                                                  comp.version,
                                                  name,
                                                  COMPONENT)

            compCompliance[name] = _getCompCompliance(status,
                                                      comp,
                                                      target,
                                                      SOURCE_USER,
                                                      targetSource,
                                                      errMsg=errMsg)

      return compCompliance

   def computeOrphanVibCompliance(self):
      """Compute orphan VIB compliance and returns a compliant status, which
         is one of compliant, non-compliant and incompatible.
         Side effect: a warning notification will be added for orphan VIBs
         to be removed, an error notification will be added for orphan VIBs
         to be downgraded.
      """
      hostOrphanVibIds = self.currentSoftwareScanSpec[ORPHAN_VIBS]
      if not hostOrphanVibIds:
         return COMPLIANT

      # The host is non-compliant as there must be at least some metadata
      # changes.
      status = NON_COMPLIANT

      hostVibs = self.hostImageProfile.vibs
      desiredVibs = self.desiredImageProfile.vibs

      # We only need to look deeper into orphan VIBs that are not in the
      # desired image to generate notifications.
      orphanVibs = [hostVibs[vibId] for vibId in hostOrphanVibIds
                    if not vibId in desiredVibs]
      if orphanVibs:
         allVibs = VibCollection()
         allVibs += desiredVibs
         for vib in orphanVibs:
            allVibs.AddVib(vib)

         downgradedVibs, removedVibs = dict(), dict()
         scanResult = allVibs.Scan()
         for vib in orphanVibs:
            if scanResult.vibs[vib.id].replaces:
               # VIB being downgraded.
               downgradedVibs[vib.name] = vib.versionstr
            elif not scanResult.vibs[vib.id].replacedBy:
               # VIB is simply removed.
               removedVibs[vib.name] = vib.versionstr

         # Downgraded and removed VIBs generate warnings.
         if downgradedVibs:
            # Downgrade is not supported, thus the incompatible status.
            status = INCOMPATIBLE
            vibDetails = ['%s(%s)' % (name, version) for name, version in
                          downgradedVibs.items()]
            errMsg = getNotification(VIB_DOWNGRADE_ID,
                                     VIB_DOWNGRADE_ID,
                                     msgArgs=[', '.join(vibDetails)])
            self.overallNotifications.errors.append(errMsg)

         if removedVibs:
            vibDetails = ['%s(%s)' % (name, version) for name, version in
                          removedVibs.items()]
            warnMsg = getNotification(VIB_REMOVAL_ID,
                                      VIB_REMOVAL_ID,
                                      msgArgs=[', '.join(vibDetails)])
            self.overallNotifications.warnings.append(warnMsg)

      return status

   def formHostComplianceResult(self, baseImageCompliance, addOnCompliance,
                                hspCompliance, componentsCompliance,
                                solutionsCompliance, orphanVibStatus):
      """
      Compute the overall host compliance based on base image, addon, solutions
      and user components compliance info, as well orphan VIB compliance
      status.
      If any of the compliance computation fails then the status will be
      returned as UNAVAILABLE.
      """

      # Execute hardware precheck.
      try:
         if HostOSIsSimulator():
            # Skip hardware compatibilty check in simulators as there are  unmet
            # assumptions in the environment, e.g locker partition do not exist.
            precheckCompatible = True
         else:
            precheckCompatible = self.checkHardwareCompatibility()
      except Exception as e:
         self.reportErrorResult('Failed to check hardware compatibility', e)

      try:
         impact = self.computeImageImpact()
      except InstallerNotAppropriate as e:
         self.reportErrorResult('Failed to compute impact', e)

      complianceStatus = set()
      if baseImageCompliance:
         complianceStatus.add(str(baseImageCompliance.status))
      if addOnCompliance:
         complianceStatus.add(str(addOnCompliance.status))
      if hspCompliance:
         for value in hspCompliance.values():
            complianceStatus.add(str(value.status))
      if componentsCompliance:
         for value in componentsCompliance.values():
            complianceStatus.add(str(value.status))
      if solutionsCompliance:
         for value in solutionsCompliance.values():
            complianceStatus.add(str(value.status))
      if isNotNone(orphanVibStatus):
         complianceStatus.add(orphanVibStatus)
      if not precheckCompatible:
         complianceStatus.add(INCOMPATIBLE)

      # Overall compliance status.
      # Unavailable: if any image piece reports unavailable.
      # Incompatible: if any image piece reports incompatible, or the
      #               precheck result contains an error.
      # non-compliant: if any image piece reports non-compliant.
      # compliant: if none of the above applies.
      overallStatus = COMPLIANT
      if UNAVAILABLE in complianceStatus:
         overallStatus = UNAVAILABLE
      elif INCOMPATIBLE in complianceStatus:
         overallStatus = INCOMPATIBLE
      elif NON_COMPLIANT in complianceStatus:
         overallStatus = NON_COMPLIANT

      # Re-process all notification lists to use optional when applicable.
      notifications = Notifications(
                  info=getOptionalVal(self.overallNotifications.info),
                  warnings=getOptionalVal(self.overallNotifications.warnings),
                  errors=getOptionalVal(self.overallNotifications.errors))

      return HostCompliance(impact=ComplianceImpact(impact),
                            status=ComplianceStatus(overallStatus),
                            notifications=notifications,
                            scan_time=datetime.utcnow(),
                            base_image=baseImageCompliance,
                            add_on=addOnCompliance,
                            hardware_support=hspCompliance,
                            components=componentsCompliance,
                            solutions=solutionsCompliance)

   def scan(self):
      """Scan the host compliance.
      """
      # This method assumes the task is already in progress, and complete
      # the task with increments.
      progressStep = (100 - self.task.progress) // 12

      depoMgr = DepotMgr(depotSpecs=self.depotSpec, connect=True)
      swMgr = SoftwareSpecMgr(softwareSpec=self.swSpec,
                              depotManager=depoMgr)
      # Notification lists must be explicitly initiated to empty lists to
      # allow additions.
      self.overallNotifications = Notifications(info=[], warnings=[], errors=[])
      self.task.setProgress(self.task.progress + progressStep)

      try:
         self.desiredImageProfile = swMgr.validateAndReturnImageProfile()
         self.hostImage = HostImage()
         # The current live image is what we really want to scan against
         # as any pending reboot image will be discarded by apply.
         self.hostImageProfile = self.hostImage.GetProfile(
                                             database=HostImage.DB_VISORFS)
         self.currentSoftwareScanSpec = self.getImageProfileScanSpec()
         self.task.setProgress(self.task.progress + progressStep)
      except Exception as e:
         msg = "Failed to validate/extract the softwareSpec"
         self.reportErrorResult(msg, e)

      # Compare logic for base image
      try:
         baseImageCompliance = self.computeBaseImageCompliance()
         self.task.setProgress(self.task.progress + progressStep)
      except Exception as e:
         msg = "Failed to compute base image compliance for the host"
         self.reportErrorResult(msg, e)

      # Compare logic for addon
      try:
         addOnCompliance = self.computeAddOnCompliance()
         self.task.setProgress(self.task.progress + progressStep)
      except Exception as e:
         msg = "Failed to compute addon compliance for the host"
         self.reportErrorResult(msg, e)

      # Compare logic for components
      try:
         componentsCompliance = self.computeComponentsCompliance()
         self.task.setProgress(self.task.progress + 2 * progressStep)
      except Exception as e:
         msg = "Failed to compute component compliance for the host"
         self.reportErrorResult(msg, e)

      # Compliance for hardware support packages.
      try:
         hspCompliance = self.computeHardwareSupportCompliance()
         self.task.setProgress(self.task.progress + 2 * progressStep)
      except Exception as e:
         msg = "Failed to compute hardware support compliance for the host"
         self.reportErrorResult(msg, e)

      # Compliance logic for solutions.
      try:
         solutionsCompliance = self.computeSolutionCompliance()
         self.task.setProgress(self.task.progress + 2 * progressStep)
      except Exception as e:
         msg = "Failed to compute solution compliance for the host"
         self.reportErrorResult(msg, e)

      # Orphan VIBs compliance
      try:
         orphanVibCompStatus = self.computeOrphanVibCompliance()
         self.task.setProgress(self.task.progress + progressStep)
      except Exception as e:
         msg = "Failed to compute orphan VIB compliance for the host"
         self.reportErrorResult(msg, e)

      complianceResult = self.formHostComplianceResult(baseImageCompliance,
                                                       addOnCompliance,
                                                       hspCompliance,
                                                       componentsCompliance,
                                                       solutionsCompliance,
                                                       orphanVibCompStatus)
      self.task.completeTask(result=vapiStructToJson(complianceResult))
