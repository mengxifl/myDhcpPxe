########################################################################
# Copyright (C) 2010-2017 VMWare, Inc.
# All Rights Reserved
########################################################################

"""'Misc utility functions
"""
import sys

def isPython3OrLater():
   """Return True if pyhton 3.0 or newer.
   """
   return sys.version_info[0] >= 3

def isString(objInstance):
   """Check whether the given object is a string.
   """
   if isPython3OrLater():
      return isinstance(objInstance, str)
   else:
      return isinstance(objInstance, basestring)

def byteToStr(byteString):
   """Convert an ascii byte string into a python native string.
   """
   return "".join(['%c' % c for c in byteString])

def seekable(fobj):
   """Check whether a file object supports '.seek()'.
   """
   try:
      return fobj.seekable()
   except AttributeError:
      # Python2 does not support .seekable(). Resort to calling .tell(),
      # which will raise an AttributeError if .seek() is not supported.
      try:
         _ = fobj.tell()
      except AttributeError:
         return False
      else:
         return True
