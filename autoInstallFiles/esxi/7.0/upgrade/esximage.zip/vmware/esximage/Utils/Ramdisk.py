########################################################################
# Copyright (C) 2016-2019 VMWare, Inc.                                 #
# All Rights Reserved                                                  #
########################################################################

import logging
import os
import shutil
import tarfile
import tempfile
from functools import lru_cache

log = logging.getLogger('Ramdisk')

from vmware.runcommand import runcommand, RunCommandError

from . import HostInfo
from .. import Errors
from .Misc import byteToStr
from ..Version import Version

RAMDISK_ADD_CMD = 'localcli system visorfs ramdisk add -m 0 -M %s ' \
                  '-n %s -p 755 -t %s'
RAMDISK_RM_CMD = 'localcli system visorfs ramdisk list | grep /%s && ' \
                 'localcli system visorfs ramdisk remove -t %s'
SECURE_MOUNT_SCRIPT = '/usr/lib/vmware/secureboot/bin/secureMount.py'

def RemoveRamdisk(name, target):
   '''Unmount and remove a ramdisk.
   '''
   try:
      if os.path.exists(target):
         cmd = RAMDISK_RM_CMD % (name, target)
         rc, _ = runcommand(cmd)
         shutil.rmtree(target)
   except RunCommandError as e:
      log.warning('Failed to run %s: %s' % (cmd, e))
   except EnvironmentError as e:
      log.warning('Cannot remove %s directory: %s' % (target, e))

def CreateRamdisk(size, name, target):
   """Create and mount a ramdisk.
   """
   try:
      os.makedirs(target)
      cmd = RAMDISK_ADD_CMD % (size, name, target)
      rc, out = runcommand(cmd)
   except EnvironmentError as e:
      RemoveRamdisk(name, target)
      msg = 'Failed to create ramdisk %s' % name
      raise Errors.InstallationError(e, None, msg)
   except RunCommandError as e:
      RemoveRamdisk(name, target)
      msg = ('Failed to run %s: %s' % (cmd, e))
      raise Errors.InstallationError(e, None, msg)
   if rc != 0:
      RemoveRamdisk(name, target)
      msg = ('Failed to run %s: %s' % (cmd, byteToStr(out)))
      raise Errors.InstallationError(e, None, msg)

@lru_cache()
def isRamdiskMountSupported():
   """Checks the SECURE_MOUNT_SCRIPT option for ramdisk support."""
   _, out = runcommand(SECURE_MOUNT_SCRIPT)
   # evalutes to true for the new and old interface
   return 'ramdisk' in out.decode()

@lru_cache()
def isIgnoreSigErrOptionAvailable():
   """Check if the --ignoreSigError option is available.

   If this option is not present, the SECURE_MOUNT_SCRIPT doesn't value
   signature violation. The option is required to proceed the mount
   if a violation occurs (e.g., force live mount of VIBs).
   """
   cmd = "%s ramdisk -h" % SECURE_MOUNT_SCRIPT
   _, out = runcommand(cmd)
   return "--ignoreSigError" in out.decode()

def MountTardiskInRamdisk(vibArg, payloadName, tardiskPath, ramdiskName,
                          ramdiskPath, bootPath=None, checkAcceptance=True):
   """Mount and attach a tardisk to an existing ramdisk.
      Parameters:
         vibArg      - VIB ID or the path to the VIB file; secureMount requires
                       this to verify the tardisk
         payloadName - the name of the payload associated with the tardisk
         tardiskPath - local path of a tardisk
         ramdiskName - name of the ramdisk to attach the tardisk
         ramdiskPath - path to the ramdisk
         bootPath    - path to a boot directory (containing imgdb and boot.cfg)
         checkAcceptance - don't mount a tardisk if the signature validation fails
   """

   if isRamdiskMountSupported():
      try:
         log.info('Mount tardisk %s in ramdisk %s', tardiskPath, ramdiskPath)
         curVer = HostInfo.GetEsxVersion()
         if Version.fromstring(curVer) >= Version.fromstring('6.8.8'):
            # secureMount.py API was changed in 6.8.8 with support of operation
            # mode input.
            cmd = '%s ramdisk -v %s -p %s -t %s -r %s' % (
               SECURE_MOUNT_SCRIPT, vibArg, payloadName, tardiskPath,
               ramdiskName)
            if bootPath:
               cmd += ' -b ' + bootPath
            if not checkAcceptance and isIgnoreSigErrOptionAvailable():
               cmd += ' --ignoreSigError'

            rc, out = runcommand(cmd)
         else:
            assert(not bootPath), 'Boot path argument is not supported in this release'
            rc, out = runcommand('%s ramdiskMount %s %s %s %s' % (
                                 SECURE_MOUNT_SCRIPT, vibArg, payloadName,
                                 tardiskPath, ramdiskName))
         if rc != 0:
            raise Errors.InstallationError(None, None,
                                           'secureMount returns status %d, '
                                           'output: %s' % (rc, byteToStr(out)))
      except RunCommandError as e:
         log.warning('Failed to execute secureMount: %s', str(e))

   elif not checkAcceptance:
      # Fallback to extraction on failure, this happens during an upgrade
      # where an old secureMount script is present and does not support
      # the ramdiskMount operation.
      # This path doesn't include any secure boot checks and it is the
      # responsibility of the caller to ensure sufficent checks.
      log.info('Fallback to extract tardisk %s', tardiskPath)
      try:
         with tempfile.NamedTemporaryFile() as tmpFd:
            rc, out = runcommand('vmtar -x %s -o %s'
                                 % (tardiskPath, tmpFd.name))
            log.debug('vmtar returns %d, output: %s', rc, byteToStr(out))
            with tarfile.open(tmpFd.name, 'r') as tarFile:
               tarFile.extractall(ramdiskPath)
      except (RunCommandError, tarfile.TarError) as e:
         msg = 'Failed to extract tardisk %s in ramdisk %s: %s' \
               % (tardiskPath, ramdiskPath, str(e))
         raise Errors.InstallationError(e, None, msg)
   else:
      msg = 'Current ESXi version does not provide a mechanism to mount a ' \
            'tardisk into a ramdisk.'
      raise Errors.InstallationError(None, None, msg)


def UnmountManualTardisk(tardiskName):
   """Unmount tardisk mounted in tardisks.noauto.
      Such tardisks are mounted to be attached to a ramdisk.
      Parameter:
         tardiskName - filename of the tardisk to be unmounted
   """
   TARDISKS_NOAUTO_PATH = '/tardisks.noauto'

   tardiskPath = os.path.join(TARDISKS_NOAUTO_PATH, tardiskName)
   if os.path.exists(tardiskPath):
      try:
         log.info('Unmounting manual tardisk %s' % tardiskPath)
         os.remove(tardiskPath)
      except Exception as e:
         msg = 'Failed to unmount manual tardisk %s: %s' % (tardiskPath, str(e))
         raise Errors.InstallationError(e, None, msg)

