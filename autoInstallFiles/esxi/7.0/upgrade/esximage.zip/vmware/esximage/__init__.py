import os
import sys

MIB = 1024 * 1024

# In esxcli upgrade, esximage library runs on a legacy host. We need to amend
# sys.path to include paths for importing other new libraries:
# - uefi module for UEFI boot option manipulation.
# - systemStorage.upgradeUtils and its dependencies for boot disk partition
#   layout manipulation.
# - esxutils for misc tools.

modulePath = os.path.dirname(os.path.abspath(__file__))
if '/tmp/' in modulePath and not '.zip' in modulePath:
   # esxcli upgrade mounts esx-update VIB in /tmp, and not in a zip.
   # In this case esximage path should be like:
   # /tmp/esx-update-<pid>/lib64/python<ver>/site-packages/vmware/esximage
   sitePkgPath = os.path.normpath(os.path.join(modulePath, '..', '..'))
   mountRoot = os.path.normpath(os.path.join(sitePkgPath, '..', '..', '..'))
   if mountRoot is not '/':
      sysStorageZip = os.path.join(mountRoot, 'usr', 'lib', 'vmware',
                                   'esxupdate', 'systemStorage.zip')
      for path in (sitePkgPath, sysStorageZip):
         if not path in sys.path:
            # The legacy esximage lib may have added some of these paths.
            sys.path.insert(0, path)

# Enablement flag of the system storage feature, conditioned by both the
# SystemStorageNext FSS and VMKernel UserVar.
#  - On ESX 6.x (when this script is pushed to the host in an upgrade), the
#    SystemStorageNext FSS doesn't exist. The feature is enabled here to be
#    in sync with 7.x and can be disabled by manually setting the
#    SystemStorageNext UserVar to 0,
#  - On ESX 7.x, the SystemStorageNext FSS controls the feature enablement.

fssNames = ['SystemStorageNext', 'PersonalityManagerSoftware', 'ConfigStoreStage2',
            'ESX_RestrictStickyFiles']
fssVals = []
hasSystemStorageFss = False
try:
   import featureState
   featureState.init(False)
   for fss in fssNames:
      try:
         fssVals.append(getattr(featureState, fss))
         if fss == 'SystemStorageNext':
            hasSystemStorageFss = True
      except AttributeError:
         # Legacy ESXi.
         fssVals.append(False)
except ImportError:
   fssVals = [False] * len(fssNames)

(SYSTEM_STORAGE_ENABLED, PMAN_ENABLED, CONFIG_STORE_ENABLED,
 RESTRICT_STICKY_FILES_ENABLED) = fssVals

if not hasSystemStorageFss:
   # Check the UserVar if the feature is not found.
   try:
      # On 6.x, this requires the above sys.path manipulation.
      # Disable System-Storage feature upgrade if the user explicity disables it
      # in the UserVar.
      import advcfg
      SYSTEM_STORAGE_ENABLED = advcfg.getUserVar('SystemStorageNext') != 0
   except Exception:
      # Variable not found, enable system-storage in legacy version.
      SYSTEM_STORAGE_ENABLED = True


def Configure(**kwargs):
   """This function is used to configure various aspects of the module's
      operation. The following keyword arguments are accepted:
         * nettimeout    - A positive integer or float giving the amount of time
                           to wait for reads from a connection to an HTTP, HTTPS
                           or FTP server. May also be None or 0, which disables
                           the timeout.
         * netretries    - A positive integer specifying the number of times to
                           retry a connection to an HTTP, HTTPS or FTP server.
                           A value of 0 causes infinite retries. This may also
                           be None, which disables retrying.
         * netratelimit  - A positive integer specifying, in bytes per second,
                           the maximum bandwidth to use for HTTP, HTTPS and FTP
                           downloads.
         * certsdir      - Specifies a path to a directory containing the
                           certificates to be used for acceptance level
                           verification.
         * schemadir     - Specifies a path to a directory containing the
                           schemas to be used for acceptance level verification
                           and schema validation.
         * jsonschemadir - Specifies a path to a directory containing the
                           json schemas to be used for schema validation.
   """
   if "nettimeout" in kwargs:
      from . import Downloader
      Downloader.SetTimeout(kwargs.pop("nettimeout"))
   if "netretries" in kwargs:
      from . import Downloader
      Downloader.SetRetry(kwargs.pop("netretries"))
   if "netratelimit" in kwargs:
      from . import Downloader
      Downloader.SetRateLimit(kwargs.pop("netratelimit"))
   if "jsonschemadir" in kwargs:
      from .Utils import JsonSchema
      JsonSchema.SCHEMA_ROOT = kwargs.pop("jsonschemadir")
   if "schemadir" in kwargs:
      from . import Bulletin, ImageProfile, Vib
      for module in (Bulletin, ImageProfile, Vib):
         module.SCHEMADIR = kwargs["schemadir"]

   al_args = dict()
   for key in ("certsdirs", "schemadir"):
      if key in kwargs:
         al_args[key] = kwargs.pop(key)

   if al_args:
      from . import AcceptanceLevels
      AcceptanceLevels.Initialize(**al_args)

   if kwargs:
      raise TypeError("configure() got unexpected keyword argument(s): %s"
                      % ", ".join(kwargs))
