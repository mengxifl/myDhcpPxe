########################################################################
# Copyright (C) 2017-2018 VMWare, Inc.                                 #
# All Rights Reserved                                                  #
########################################################################

"""
Command-line wrapper for esximage.ImageBuilder library.
"""
import argparse
import json

from esximage import (Bulletin, ImageProfile, ReleaseCollection,
                      Vib, VibCollection)
from esximage.ImageBuilder.EsxIsoImage import EsxIsoImage
from esximage.ImageBuilder.EsxPxeImage import EsxPxeImage

def _formImageProfile(args):
   profile = ImageProfile.ImageProfile.FromXml(args.profile.read(),
                                               validate=False)

   disabledVibs = set()
   if args.disableList:
      for line in args.disableList.readlines():
         disabledVibs.add(line.strip())

   # Populate VIBs and bulletins
   vibs = VibCollection.VibCollection()
   for vibPath in args.vibs:
      v = Vib.ArFileVib.FromFile(vibPath)
      if v.id not in disabledVibs:
         vibs.AddVib(v)
   profile.PopulateVibs(vibs)

   if args.bulletin:
      bc = Bulletin.BulletinCollection()
      for fobj in args.bulletin:
         bulletin = Bulletin.Bulletin.FromXml(fobj.read())
         bc.AddBulletin(bulletin)
      profile.PopulateBulletins(bc)

   if args.baseimage:
      bc = ReleaseCollection.BaseImageCollection()
      bc.AddFromJSON(args.baseimage.read())
      profile.PopulateBaseImage(bc)

   if args.addon:
      ac = ReleaseCollection.AddonCollection()
      ac.AddFromJSON(args.addon.read())
      profile.PopulateAddon(ac)

   # Populate ImageProfile with the reservedComponents.
   if args.reservedComponents:
      resComps = Bulletin.ComponentCollection()
      for resComp in args.reservedComponents:
         b = Bulletin.Bulletin.FromXml(resComp.read())
         comp = Bulletin.Component.FromBulletin(b)
         resComps.AddComponent(comp)
      profile.PopulateReservedComponents(resComps)

   return profile

def pxe(args):
   """Write an ESXi PXE image.
   """
   profile = _formImageProfile(args)

   # Deploy the PXE boot modules and the image database (imgdb.gz)
   img = EsxPxeImage(profile)
   img.Write(args.pxeDir, args.pxeUrl,
             installer=args.installer,
             checkacceptance=False,
             kernelopts=args.kernelopts)

   # Generate PXE record
   img.WriteRecord(args.pxeName, args.pxeRecord, args.pxeDir, args.pxeHash,
                   args.installer,
                   args.pxeName.replace('-pxe', ''),
                   opts=args.options,
                   kernelopts=args.kernelopts)


def iso(args):
   """Write an ESXi ISO image.
   """
   profile = _formImageProfile(args)

   iso = EsxIsoImage(profile)
   # Cannot check VIB signatures; no VibSign module available
   iso.Write(args.output, installer=args.installer,
             checkacceptance=False, kernelopts=args.kernelopts)


def main(args=None):
   parser = argparse.ArgumentParser(prog='python -m esximage.ImageBuilder')

   subparsers = parser.add_subparsers(dest='cmd', title='Image Type')

   pxeParser = subparsers.add_parser('pxe', help='PXE imagebuilder help')
   isoParser = subparsers.add_parser('iso', help='ISO imagebuilder help')

   # Common arguments
   for p in (pxeParser, isoParser):
      # python2to3 note: FileType('r', encoding='UTF-8')
      p.add_argument('--profile', help="ImageProfile defining image",
                     type=argparse.FileType('r'), required=True)
      p.add_argument('--disableList', help="File of VIBs to exclude",
                     type=argparse.FileType('r'))
      p.add_argument('--installer', help="Enable installer in PXE/ISO image",
                     action='store_true')
      p.add_argument('--kernelopts', help="Additional kernel boot options (JSON)",
                     type=json.loads)
      p.add_argument('vibs', help="VIB files to include",
                     nargs="*")
      p.add_argument('--bulletin', help="Bulletin files to include",
                     type=argparse.FileType('r'), nargs="*")
      p.add_argument('--baseimage', help="Base image to include",
                     type=argparse.FileType('r'))
      p.add_argument('--addon', help="AddOn to include",
                     type=argparse.FileType('r'))
      p.add_argument('--reservedComponents', nargs="*",
                     help="Reserved component files to include",
                     type=argparse.FileType('r'))

   # PXE-only arguments
   pxeParser.add_argument('--pxeName', help="PXE record name (required)",
                          required=True)
   pxeParser.add_argument('--pxeHash', help="Hash to distinguish PXE trees (required)",
                          required=True)
   pxeParser.add_argument('--pxeDir', help="Output PXE directory (required)",
                          required=True)
   pxeParser.add_argument('--pxeRecord', help="Output PXE record filename (required)",
                          required=True)
   pxeParser.add_argument('--pxeUrl', help="Http url to PXE output directory, required to"
                          " make http-ready PXE image")
   pxeParser.add_argument('--options', help="Additional options for pxe-boot script (JSON)",
                          type=json.loads, required=True)
   pxeParser.set_defaults(func=pxe)

   # ISO-only arguments
   isoParser.add_argument('--output', help="ISO output path",
                          type=argparse.FileType('wb'), required=True)
   isoParser.set_defaults(func=iso)

   args = parser.parse_args()

   # Useful for debugging...
   # print(vars(args))

   args.func(args)

if __name__ == "__main__":
   main()
