# Required to distribute different parts of this
# package as multiple distributables
try:
    __import__('pkg_resources').declare_namespace(__name__)
except ImportError:
   try:
      from pkgutil import extend_path
      __path__ = extend_path(__path__, __name__)
   except ImportError:
      pass
