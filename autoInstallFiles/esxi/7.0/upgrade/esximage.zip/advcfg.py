# Copyright 2019 VMware, Inc.
# All rights reserved. -- VMware Confidential

"""ESX Advanced Config Options.

TODO:
  - In {addStr|delete}UserVar(), make direct calls to VSI through vmware.vsi to
    avoid forking esxcfg-advcfg.
"""
import subprocess

from esxutils import runCli, EsxcliError

def _esxcfgAdvcfg(args):
   """Helper function to wrap calls to esxcfg-advcfg
   """
   _ESXCFG_ADVCFG = "/usr/lib/vmware/bin/esxcfg-advcfg"

   p = subprocess.run([_ESXCFG_ADVCFG] + args, stderr=subprocess.PIPE)
   if p.returncode != 0:
      raise OSError("esxcfg-advcfg: %s" % p.stderr.decode())

   return p

def addStrUserVar(name, desc, default, hidden=False):
   """Register a new Advanced Config Option in the /UserVars tree.
   """
   args = ['--add-option', name,
           '--add-type', 'string',
           '--add-desc', desc,
           '--add-default', default]
   if hidden:
      args += ['--add-hidden', 'true']

   try:
      _esxcfgAdvcfg(args)
   except OSError:
      raise OSError("/UserVars/%s: failed to add string AdvancedOption" % name)

def deleteUserVar(name):
   """Register a new Advanced Config Option in the /UserVars tree.
   """
   args = ['--del-option', name]

   try:
      _esxcfgAdvcfg(args)
   except OSError:
      raise OSError("/UserVars/%s: failed to delete Advanced Option" % name)

def getUserVar(name, *args):
   """Get a UserVars Advanced Option. The optional args parameter returns the
      user specified default value if the key is not found, otherwise
      a KeyError exception will be raised if nothing is passed in.
   """
   try:
      opt = runCli(['system', 'settings', 'advanced', 'list', '-o',
                    '/UserVars/%s' % name], evalOutput=True)[0]
   except EsxcliError:
      if len(args) > 0:
         return args[0]
      else:
         raise KeyError("%s: Advanced User Option is not defined" % name)

   return opt['Int Value' ] if opt['Type'] == 'integer' else opt['String Value']

def setUserVar(name, value):
   """Set a UserVars Advanced Option.
   """
   runCli(['system', 'settings', 'advanced', 'set',
           '-o', "/UserVars/%s" % name,
           '-i' if isinstance(value, int) else '-s', str(value)])

def getVmkCfgOpt(name, default=False):
   """Get a VMKernel Config Option.
   """
   opt = runCli(['system', 'settings', 'kernel', 'list', '-o', name],
                evalOutput=True)[0]
   if default:
      value = opt['Default']
   else:
      value = opt['Runtime']

   if opt['Type'].startswith(('int', 'uint')):
      return int(value)
   elif opt['Type'] == 'Bool':
      return value.lower() == 'true'
   else:
      return value
