#!/usr/bin/python

# Copyright 2019 VMware, Inc.
# All rights reserved. -- VMware Confidential

"""ESX utility to generate a .DD image off of a live ESX host.

This script collects all ESX payloads from the current running system, and
generates a .DD image off of these payloads. On PXE-booted systems, the bootbank
payloads are retrieved from the PXE directory, whose URL is set in the 'bootUrl'
VMKernel boot option.
"""
import os
from tempfile import TemporaryDirectory

from borautils.busybox import wget
from esxutils import getVmkBootOptions
from systemStorage import BOOTBANK_LINK, LOCKER_LINK
from systemStorage.ddImage import DDImage
from systemStorage.esxboot import BOOTLOADER_DIR
from vmware.esximage.Utils.BootCfg import BootCfg

def fetchBootbankFilesFromPxeDir(bootUrl, cacheDir):
   """Fetch the bootbank files from the current PXE directory.

   Download ESX boot files from the given boot URL. This function assumes
   that the system was booted over HTTP.
   """
   MBOOT_CFG = 'boot.cfg'

   localBootCfg = os.path.join(cacheDir, MBOOT_CFG)
   wget(os.path.join(bootUrl, MBOOT_CFG), localBootCfg)

   bootCfg = BootCfg(localBootCfg)
   bootCfg.kernelopt.pop('bootUrl', None)
   bootCfg.kernelopt['debugLogToSerial'] = '1'
   bootCfg.kernelopt['logPort'] = 'com1'
   bootCfg.kernelopt['esxDDImage'] = 'TRUE'
   bootCfg.timeout = 3
   bootCfg.updated = BootCfg.BOOTSTATE_UPDATED
   with open(localBootCfg, 'wb+') as cfg:
      bootCfg.write(cfg)

   bootFiles = ([bootCfg.kernel] + bootCfg.modules)

   for relPath in bootFiles:
      url = os.path.join(bootUrl, relPath)
      localPath = os.path.join(cacheDir, relPath)
      wget(url, localPath)

def live2dd(output, bootOpts=None, stageDir=None):
   """Generate an ESX .DD image from a live ESX host.
   """
   ddImage = DDImage(output)

   with TemporaryDirectory(prefix='_live2dd', dir=stageDir) as tmpDir:
      try:
         bootUrl = getVmkBootOptions()['bootUrl']
      except KeyError:
         bootbank1Dir = BOOTBANK_LINK
      else:
         bootbank1Dir = os.path.join(tmpDir, 'bootbank1')
         os.mkdir(bootbank1Dir)
         fetchBootbankFilesFromPxeDir(bootUrl, bootbank1Dir)

      ddImage.write(BOOTLOADER_DIR, bootbank1Dir, LOCKER_LINK)


if __name__ == "__main__":
   from argparse import ArgumentParser

   desc = "Generate ESX DD images."

   parser = ArgumentParser(description=desc)
   parser.add_argument('output', help="Path to output file")
   parser.add_argument('--stageDir', metavar='STAGEDIR',
                       help="Staging directory to use")

   args = parser.parse_args()

   live2dd(args.output, stageDir=args.stageDir)
