# Copyright 2019 VMware, Inc.
# All rights reserved. -- VMware Confidential

"""Functions related to scratch on ESXi host.
"""
import os

from systemStorage import FS_TYPE_VMFS, OSDATA_LINK
from systemStorage.esxdisk import EsxDisk
from systemStorage.esxfs import getFssVolumes

LOCKER_DOT_CONF = "/etc/vmware/locker.conf"

def getDefaultScratchPath():
   """Retrieve the default scratch path.

   In a booted system, the OSdata symlink points to the default scratch
   location, which can be a VMFS-L partition or a datastore .locker path.
   OSdata path is not affected by the scratch location advanced config.
   """
   if os.path.islink(OSDATA_LINK):
      return os.path.realpath(OSDATA_LINK)
   raise OSError("OSdata link does not exist")

def setScratchDir(path):
   """Configure the path to the scratch volume.

   Passing None to this function allows to clear (reset) the path to /scratch.
   Reboot is required for the new path to take effect.
   """
   if path is None:
      open(LOCKER_DOT_CONF, 'w').close()
   else:
      os.makedirs(path, exist_ok=True)
      with open(LOCKER_DOT_CONF, 'w') as lockerConf:
         lockerConf.write("%s 0\n" % os.path.realpath(path))

def getConfiguredScratchDir():
   """Return the path to scratch as configured in locker.conf.
   """
   try:
      with open(LOCKER_DOT_CONF, 'r') as lockerConf:
         data = lockerConf.read()
      return data.strip().partition(' ')[0]
   except Exception:
      return ""

def getDatastoreScratchPath():
   """Identify a datastore path that can be used for scratch.

   This is to support the legacy behavior of scratch assignment when there's no
   high quality persistent storage other than datastores.
   """
   MIN_SCRATCH_DS_SIZE = 4000000000

   vols = sorted(getFssVolumes(fsType=FS_TYPE_VMFS), key=lambda v: v.diskName)
   for vol in vols:
      if vol.size < MIN_SCRATCH_DS_SIZE:
         continue

      # verify disk is not USB and is local (KB-1033696)
      disk = EsxDisk(vol.diskName, devInfoOnly=True)
      if not disk.isUsb and disk.isLocal:
         return os.path.join(vol.path, ".locker")

   return ""
